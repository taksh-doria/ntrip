﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net.Mail;

using System.IO;
using System.IO.Ports;
using System.Net.Sockets;
using System.Net;
using System.Timers;
using System.Diagnostics;
using System.Threading;

using GMap;
using GMap.NET.WindowsForms;
using GMap.NET.MapProviders;
using GMap.NET.Analytics;
using GMap.NET.CacheProviders;
using GMap.NET.Internals;
using GMap.NET.Properties;

using PdfSharp;
using PdfSharp.Drawing;
using PdfSharp.Pdf;
using PdfSharp.Pdf.IO;

using MySql.Data.MySqlClient;


namespace NMEA_Serial_out
{
    public partial class NMEA_OUT : Form
    {

         MySqlConnection connection;
         
         string server;
         string database;
         string uid;
         string password;

        int global_cnt = 0;
        string raw_file_path_G = "";
        string[] alldata_str_G;

         string   port_name,baudrate,databits ,parity, stopbits ,handshake,filepath;
         public static string internalLog = "";
         string filepath_raw;
         string filepath_vehicle;
         FileStream fsIn; 
         StreamReader sr;
         int loop_Count = 5;
         bool display_flag = true;
         Thread Thread1; 
         string CMD;
         string str;
         StreamWriter w2;
         public static int send_data_flag = 0;
         public static string char_buf;
         public static char[] char_arr = new char[500];
         int Stop_flag = 0;
          string UTC;// = NMEA_TOKEN_STR[i++];
          string   VALID_FIX;// = NMEA_TOKEN_STR[i++];
          string  LAT;// = NMEA_TOKEN_STR[i++];
          string  LAT_DGN;// = NMEA_TOKEN_STR[i++];
          string  LON;// = NMEA_TOKEN_STR[i++];
          string  LON_DGN;// = NMEA_TOKEN_STR[i++];
          string  VEL;// = NMEA_TOKEN_STR[i++];
          string  COG ;//= NMEA_TOKEN_STR[i++];
          string  DATE;// = NMEA_TOKEN_STR[i++];
          string  VALID_MODE;// = NMEA_TOKEN_STR[i++];
          string  NSATS;//= NMEA_TOKEN_STR[i++];
          string  HDOP ;//= NMEA_TOKEN_STR[i++];
          string  ALT;//= NMEA_TOKEN_STR[i++];
          string ALT_UNIT;// = NMEA_TOKEN_STR[i++];

         public static double UX;
         public static double UY ;
         public static double UZ ;

         public static double UX_PREV;
         public static double UY_PREV;
         public static double UZ_PREV;

         public static double RSSError ;
         public static double user_Lat ;
         public static double user_Lon ;
         public static double user_Alt;
         public static double user_Lat_prev ;
         public static double user_Lon_prev;
         public static double user_Alt_prev;
         public static double PDOP;
         public static int noOfSatsLocked;

         string[] NMEA_TOKEN_STR;
         GMapOverlay ov;
         List<GMap.NET.PointLatLng> pp_LL = new List<GMap.NET.PointLatLng>();
         List<GMap.NET.PointLatLng> pp_LL_all = new List<GMap.NET.PointLatLng>();

         int trip_image_flag = 1;

         double[] length_arr = new double[10000];
         string[] trip_id = new string[10000];
         string[] start_time = new string[10000];
         string[] end_time = new string[10000];
         string vehicle_num = "";
         DateTime thisDate;
         DateTimeOffset thisTime;
         int id_count = 0;
         int entry_count = 0;

         double total_dist = 0;
         double total_dist_haversine = 0;
         double total_dist_3d = 0;
         double trip_dist = 0;
         int timer_2_count = 0;
          
        public NMEA_OUT()
        {
            InitializeComponent();
            gMapControl2.MapProvider = GoogleMapProvider.Instance;
            GMap.NET.MapProviders.GMapProvider.WebProxy = null;
            //get tiles from server only
            gMapControl2.Manager.Mode = GMap.NET.AccessMode.ServerAndCache;
            //not use proxy
            //center map on moscow

            //zoom min/max; default both = 2 
            gMapControl2.MinZoom = 1;
            gMapControl2.MaxZoom = 20;
            //set zoom
            gMapControl2.Zoom = 15;
            ov = new GMapOverlay(gMapControl2, "OverlayOne");

           


        }

        private void read_data(object c)
        {
           // CheckForIllegalCrossThreadCalls = false;
            string current_system_time_log = System.DateTime.Now.Year + "-" + System.DateTime.Now.Month + "-" + System.DateTime.Now.Day + "_" + System.DateTime.Now.Hour + "-" + System.DateTime.Now.Minute + "-" + System.DateTime.Now.Second;
            internalLog = "IRNSS" + current_system_time_log;
            Directory.CreateDirectory(internalLog);
            filepath_raw = internalLog + "\\raw_data.csv";


            COM_OUT.BaudRate = 115200;
          
            int log_count = 0;
            double line_count = 0;
            //textBox2.Text = "";
           // textBox2.Text = current_system_time_log +" Reading Start\r\n";
            timer1.Enabled = true;
            while (true)
            {  
                Stop_flag = 0;

               // current_system_time_log = System.DateTime.Now.Year + "-" + System.DateTime.Now.Month + "-" + System.DateTime.Now.Day + "_" + System.DateTime.Now.Hour + "-" + System.DateTime.Now.Minute + "-" + System.DateTime.Now.Second;
          
                
                try  
                { 

                    if (COM_OUT.BytesToRead > 0)
                    { 
                        str = COM_OUT.ReadLine();
                        string[] byThis = str.Split(new string[] { ":","\r" }, StringSplitOptions.RemoveEmptyEntries);
                        string[] byThis2 = str.Split(new string[] { ":","\r" }, StringSplitOptions.RemoveEmptyEntries);
                        line_count++;
                        //Console.WriteLine(str);
                        if(byThis[0] == "ID")
                        {
                            //str = COM_OUT.ReadLine();
                            filepath_vehicle = internalLog + "\\" + byThis[1] + "_" + log_count.ToString() + ".csv";
                            log_count++;
                            line_count--;
                        }   
                     
                        //textBox2.Text = str;

                        if (str == "END\r")
                        {
                            //char_buf = "#,OVER,$";
                            //char_arr = char_buf.ToCharArray();
                            //send_data_flag = 1;
                            //COM_OUT.Write(char_arr, 0, char_arr.Length);
                            timer1.Enabled = false;
                            COM_OUT.BaudRate = 9600;
                            //timer1.Enabled = false;
                             current_system_time_log = System.DateTime.Now.Year + "-" + System.DateTime.Now.Month + "-" + System.DateTime.Now.Day + "_" + System.DateTime.Now.Hour + "-" + System.DateTime.Now.Minute + "-" + System.DateTime.Now.Second;
                             double time = (line_count*5) / 60;
                             int time_min =(int)( time * 100);
                             time = time_min / 100.0;
                             textBox2.Text = time.ToString() +" minutes Data Read Successfully \r\n";
                            
                           
                            break; 
                        } 

                        using (w2 = File.AppendText(filepath_raw))
                        {
                            w2.Write(str);
                            w2.Close();
                        }

                        using (w2 = File.AppendText(filepath_vehicle))
                        {
                            w2.Write(str);
                            w2.Close();
                        }

                           
                           
              
                    }
                    
                } 
                catch (Exception e1)
                {
                    ;
                }
            }

            COM_OUT.BaudRate = 9600;
            COM_OUT.Close();
          MessageBox.Show("File read successfully");
            button1.PerformClick();
           // Application.Exit();



        }

        private void button3_Click_1(object sender, EventArgs e)
        {
           
           
        }

        private double dist_cal(double lat1, double lon1, double lat2, double lon2)
        {
            int R = 6371000; // metres
            double φ1 = lat1 * Math.PI / 180;
            double φ2 = lat2 * Math.PI / 180;
            double Δφ = (lat2 - lat1) * Math.PI / 180;
            double Δλ = (lon2 - lon1) * Math.PI / 180;

            double a = Math.Sin(Δφ / 2) * Math.Sin(Δφ / 2) +  Math.Cos(φ1) * Math.Cos(φ2) *Math.Sin(Δλ / 2) * Math.Sin(Δλ / 2);
            double c = 2 * Math.Atan2(Math.Sqrt(a), Math.Sqrt(1 - a));

            double d = R * c;

            return (d);
        }
        private double bearing_cal(double lat1, double lon1, double lat2, double lon2)
        {
            double φ1 = lat1 * Math.PI / 180;
            double φ2 = lat2 * Math.PI / 180;
            double λ1 = lon1 * Math.PI / 180;
            double λ2 = lon2 * Math.PI / 180;
            double y = Math.Sin(λ2 - λ1) * Math.Cos(φ2);
            double x = Math.Cos(φ1) * Math.Sin(φ2) - Math.Sin(φ1) * Math.Cos(φ2) * Math.Cos(λ2 - λ1);
            double brng = Math.Atan2(y, x);
            return (brng);
        }
         
        private void NMEA_OUT_Load(object sender, EventArgs e)
        {
            CheckForIllegalCrossThreadCalls = false;
          
            string[] ports = SerialPort.GetPortNames();

            foreach (string port in ports)
            {
                portname_cb.Items.Add(port);

            }

            if (File.Exists("Config.txt"))
            {

                FileStream fsIn2 = new FileStream("Config.txt", FileMode.Open, FileAccess.Read, FileShare.Read);
                StreamReader sr2 = new StreamReader(fsIn2);
                portname_cb.Text = sr2.ReadLine();
                baudrate_cb.Text = sr2.ReadLine();
                databits_cb.Text = sr2.ReadLine();
                stopbits_cb.Text = sr2.ReadLine();
                parity_cb.Text = sr2.ReadLine();
                handshake_cb.Text = sr2.ReadLine();
                sr2.Close();
                fsIn2.Close();
            }
            else
            {
                MessageBox.Show("Config.txt file missing.\nKindly reinstall IRNSS PTR software.");
                this.Close();
            }




            Thread1 = new Thread(new ParameterizedThreadStart(read_data));


           




            
        }

        private void button1_Click(object sender, EventArgs e)
        {

           

        }

        private void button2_Click(object sender, EventArgs e)
        {
            port_name = portname_cb.SelectedItem.ToString();
            baudrate = baudrate_cb.SelectedItem.ToString();
            databits = databits_cb.SelectedItem.ToString();
            stopbits = stopbits_cb.SelectedItem.ToString();
            parity = parity_cb.SelectedItem.ToString();
            handshake = handshake_cb.SelectedItem.ToString();

            if (File.Exists("Config.txt"))
            {
                FileStream fsIn2 = new FileStream("Config.txt", FileMode.Open, FileAccess.ReadWrite, FileShare.ReadWrite);
                StreamWriter sr2 = new StreamWriter(fsIn2);
                string[] tmpStr = new string[6];
                tmpStr[0] = port_name;
                sr2.WriteLine(tmpStr[0]);
                tmpStr[1] = baudrate;
                sr2.WriteLine(tmpStr[1]);
                tmpStr[2] = databits;
                sr2.WriteLine(tmpStr[2]);
                tmpStr[3] = stopbits;
                sr2.WriteLine(tmpStr[3]);
                tmpStr[4] = parity;
                sr2.WriteLine(tmpStr[4]);
                tmpStr[5] = handshake;
                sr2.WriteLine(tmpStr[5]);

                sr2.Close();
                fsIn2.Close();
            }

            COM_OUT.PortName = port_name;
            COM_OUT.BaudRate = int.Parse(baudrate);
            COM_OUT.DataBits = int.Parse(databits);

            if (parity == "None")
                COM_OUT.Parity = Parity.None;
            else if (parity == "Even")
                COM_OUT.Parity = Parity.Even;
            else if (parity == "Mark")
                COM_OUT.Parity = Parity.Mark;
            else if (parity == "Odd")
                COM_OUT.Parity = Parity.Odd;
            else if (parity == "Space")
                COM_OUT.Parity = Parity.Space;

            if (stopbits == "None")
                COM_OUT.StopBits = StopBits.None;
            else if (stopbits == "One")
                COM_OUT.StopBits = StopBits.One;
            else if (stopbits == "OnePointFive")
                COM_OUT.StopBits = StopBits.OnePointFive;
            else if (stopbits == "Two")
                COM_OUT.StopBits = StopBits.Two;

            if (handshake == "None")
                COM_OUT.Handshake = Handshake.None;
            else if (handshake == "RequestToSend")
                COM_OUT.Handshake = Handshake.RequestToSend;
            else if (handshake == "RequestToSendXOnXOff")
                COM_OUT.Handshake = Handshake.RequestToSendXOnXOff;
            else if (handshake == "XOnXOff")
                COM_OUT.Handshake = Handshake.XOnXOff;
            try
            {

                COM_OUT.Open();
            }
            catch (Exception ee2)
            {
                MessageBox.Show("Illegal Port Selected Choose Another port");
                return;


            }
            
            
            CMD = "A";
            COM_OUT.Write(CMD);
            Thread1.Start();
            
            //char_buf = "R"; 
            //char_arr = char_buf.ToCharArray();
            //send_data_flag = 1;
        
        } 

        private void timer1_Tick(object sender, EventArgs e)
        {
            textBox2.Text =    str +"\r\n";
        }

        private void file_delete_Click(object sender, EventArgs e)
        {
            port_name = portname_cb.SelectedItem.ToString();
            baudrate = baudrate_cb.SelectedItem.ToString();
            databits = databits_cb.SelectedItem.ToString();
            stopbits = stopbits_cb.SelectedItem.ToString();
            parity = parity_cb.SelectedItem.ToString();
            handshake = handshake_cb.SelectedItem.ToString();

            if (File.Exists("Config.txt"))
            {
                FileStream fsIn2 = new FileStream("Config.txt", FileMode.Open, FileAccess.ReadWrite, FileShare.ReadWrite);
                StreamWriter sr2 = new StreamWriter(fsIn2);
                string[] tmpStr = new string[6];
                tmpStr[0] = port_name;
                sr2.WriteLine(tmpStr[0]);
                tmpStr[1] = baudrate;
                sr2.WriteLine(tmpStr[1]);
                tmpStr[2] = databits;
                sr2.WriteLine(tmpStr[2]);
                tmpStr[3] = stopbits;
                sr2.WriteLine(tmpStr[3]);
                tmpStr[4] = parity;
                sr2.WriteLine(tmpStr[4]);
                tmpStr[5] = handshake;
                sr2.WriteLine(tmpStr[5]);

                sr2.Close();
                fsIn2.Close();
            }

            COM_OUT.PortName = port_name;
            COM_OUT.BaudRate = int.Parse(baudrate);
            COM_OUT.DataBits = int.Parse(databits);

            if (parity == "None")
                COM_OUT.Parity = Parity.None;
            else if (parity == "Even")
                COM_OUT.Parity = Parity.Even;
            else if (parity == "Mark")
                COM_OUT.Parity = Parity.Mark;
            else if (parity == "Odd")
                COM_OUT.Parity = Parity.Odd;
            else if (parity == "Space")
                COM_OUT.Parity = Parity.Space;

            if (stopbits == "None")
                COM_OUT.StopBits = StopBits.None;
            else if (stopbits == "One")
                COM_OUT.StopBits = StopBits.One;
            else if (stopbits == "OnePointFive")
                COM_OUT.StopBits = StopBits.OnePointFive;
            else if (stopbits == "Two")
                COM_OUT.StopBits = StopBits.Two;

            if (handshake == "None")
                COM_OUT.Handshake = Handshake.None;
            else if (handshake == "RequestToSend")
                COM_OUT.Handshake = Handshake.RequestToSend;
            else if (handshake == "RequestToSendXOnXOff")
                COM_OUT.Handshake = Handshake.RequestToSendXOnXOff;
            else if (handshake == "XOnXOff")
                COM_OUT.Handshake = Handshake.XOnXOff;
            try
            {

                COM_OUT.Open();
            }
            catch (Exception ee2)
            {
                MessageBox.Show("Illegal Port Selected Choose Another port");
                return;


            }
 
        }  

        private void RemovFile_Click(object sender, EventArgs e)
        {

            port_name = portname_cb.SelectedItem.ToString();
            baudrate = baudrate_cb.SelectedItem.ToString();
            databits = databits_cb.SelectedItem.ToString();
            stopbits = stopbits_cb.SelectedItem.ToString();
            parity = parity_cb.SelectedItem.ToString();
            handshake = handshake_cb.SelectedItem.ToString();

            if (File.Exists("Config.txt"))
            {
                FileStream fsIn2 = new FileStream("Config.txt", FileMode.Open, FileAccess.ReadWrite, FileShare.ReadWrite);
                StreamWriter sr2 = new StreamWriter(fsIn2);
                string[] tmpStr = new string[6];
                tmpStr[0] = port_name;
                sr2.WriteLine(tmpStr[0]);
                tmpStr[1] = baudrate;
                sr2.WriteLine(tmpStr[1]);
                tmpStr[2] = databits;
                sr2.WriteLine(tmpStr[2]);
                tmpStr[3] = stopbits;
                sr2.WriteLine(tmpStr[3]);
                tmpStr[4] = parity;
                sr2.WriteLine(tmpStr[4]);
                tmpStr[5] = handshake;
                sr2.WriteLine(tmpStr[5]);

                sr2.Close();
                fsIn2.Close();
            }

            COM_OUT.PortName = port_name;
            COM_OUT.BaudRate = int.Parse(baudrate);
            COM_OUT.DataBits = int.Parse(databits);

            if (parity == "None")
                COM_OUT.Parity = Parity.None;
            else if (parity == "Even")
                COM_OUT.Parity = Parity.Even;
            else if (parity == "Mark")
                COM_OUT.Parity = Parity.Mark;
            else if (parity == "Odd")
                COM_OUT.Parity = Parity.Odd;
            else if (parity == "Space")
                COM_OUT.Parity = Parity.Space;

            if (stopbits == "None")
                COM_OUT.StopBits = StopBits.None;
            else if (stopbits == "One")
                COM_OUT.StopBits = StopBits.One;
            else if (stopbits == "OnePointFive")
                COM_OUT.StopBits = StopBits.OnePointFive;
            else if (stopbits == "Two")
                COM_OUT.StopBits = StopBits.Two;

            if (handshake == "None")
                COM_OUT.Handshake = Handshake.None;
            else if (handshake == "RequestToSend")
                COM_OUT.Handshake = Handshake.RequestToSend;
            else if (handshake == "RequestToSendXOnXOff")
                COM_OUT.Handshake = Handshake.RequestToSendXOnXOff;
            else if (handshake == "XOnXOff")
                COM_OUT.Handshake = Handshake.XOnXOff;
            try
            {

                COM_OUT.Open();
            }
            catch (Exception ee2)
            {
                MessageBox.Show("Illegal Port Selected Choose Another port");
                return;


            }

            CMD = "R";
            COM_OUT.Write(CMD);
            Thread1.Start(); 
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (internalLog == "")
                MessageBox.Show("Folder Does Not Exist");
            else
                Process.Start(internalLog);
        }

        private void SendMail_Click(object sender, EventArgs e)
        {
            try
            { 
                MailMessage mail = new MailMessage();
                SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");
                mail.From = new MailAddress("mail@gmail.com");
                mail.To.Add("girishkhare11@gmail.com");
                mail.Subject = "VTU";
                mail.Body = "mail with attachment";

                System.Net.Mail.Attachment attachment;
                attachment = new System.Net.Mail.Attachment(filepath_raw);
                mail.Attachments.Add(attachment);
                SmtpServer.UseDefaultCredentials = false;
                SmtpServer.Port = 587;
                SmtpServer.Credentials = new System.Net.NetworkCredential("girishkhare11", "password");
                SmtpServer.EnableSsl = true;

                SmtpServer.Send(mail);
                MessageBox.Show("mail Send successfully");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }

        private void PARSE_VTUDATA(string[] NMEA_TOKEN_STR, int SOL_TYPE)
        {
            int i = 0;
            UTC = NMEA_TOKEN_STR[i++];
            VALID_FIX = NMEA_TOKEN_STR[i++];
            LAT = NMEA_TOKEN_STR[i++];
            LAT_DGN = NMEA_TOKEN_STR[i++];
            LON = NMEA_TOKEN_STR[i++];
            LON_DGN = NMEA_TOKEN_STR[i++];
            VEL = NMEA_TOKEN_STR[i++];
            COG = NMEA_TOKEN_STR[i++];
            DATE = NMEA_TOKEN_STR[i++];
            VALID_MODE = NMEA_TOKEN_STR[i++];
            NSATS= NMEA_TOKEN_STR[i++];
            HDOP = NMEA_TOKEN_STR[i++];
            ALT= NMEA_TOKEN_STR[i++];
            ALT_UNIT = NMEA_TOKEN_STR[i++];

            char[] LAT_CH_ARR = LAT.ToCharArray();
            char[] LON_CH_ARR = LON.ToCharArray();

            double LAT_DEG = int.Parse(LAT_CH_ARR[0].ToString()) * 10 + int.Parse(LAT_CH_ARR[1].ToString());
            double LON_DEG = int.Parse(LON_CH_ARR[0].ToString())*100 + int.Parse(LON_CH_ARR[1].ToString()) * 10 + int.Parse(LON_CH_ARR[2].ToString());


            double LAT_MIN = double.Parse(LAT_CH_ARR[2].ToString()) * 10 + double.Parse(LAT_CH_ARR[3].ToString()) + double.Parse(LAT_CH_ARR[5].ToString())/10 + double.Parse(LAT_CH_ARR[6].ToString())/100 +double.Parse(LAT_CH_ARR[7].ToString())/1000 +double.Parse(LAT_CH_ARR[8].ToString())/10000;
            double LON_MIN = double.Parse(LON_CH_ARR[3].ToString()) * 10 + int.Parse(LON_CH_ARR[4].ToString()) * 1 + double.Parse(LON_CH_ARR[6].ToString())/10 + double.Parse(LON_CH_ARR[7].ToString())/100 + double.Parse(LON_CH_ARR[8].ToString())/1000 + double.Parse(LON_CH_ARR[9].ToString())/10000;


            user_Lat_prev = user_Lat;
            user_Lon_prev = user_Lon;
            user_Alt_prev = user_Alt;

            UX_PREV = UX;
            UY_PREV = UY;
            UZ_PREV = UZ;

            user_Lat = LAT_DEG + LAT_MIN/60;
            user_Lon = LON_DEG + LON_MIN/60;
            user_Alt = double.Parse(ALT);


            double a = 6378137.0;
            double e1 = 0.08181921804834;// 8.1819190842622e-2;
            double N = a / Math.Sqrt(1 - Math.Pow(e1, 2) * Math.Pow(Math.Sin(user_Lat * Math.PI / 180), 2));
            UX = (N + user_Alt) * Math.Cos(user_Lat * Math.PI / 180) * Math.Cos(user_Lon * Math.PI / 180);
            UY = (N + user_Alt) * Math.Cos(user_Lat * Math.PI / 180) * Math.Sin(user_Lon * Math.PI / 180);
            UZ = ((1 - Math.Pow(e1, 2)) * N + user_Alt) * Math.Sin(user_Lat * Math.PI / 180);


          

        }

        private void button3_Click(object sender, EventArgs e)
        {
             openFileDialog1.ShowDialog();
             string raw_file_path = openFileDialog1.FileName;
            //FileStream fs = new FileStream(raw_file_path, FileMode.Open, FileAccess.ReadWrite, FileShare.Read);
         //  StreamReader w3 = new StreamReader(fs);
           string [] alldata_str = File.ReadAllLines(raw_file_path);
           string current_system_time_log = System.DateTime.Now.Year + "-" + System.DateTime.Now.Month + "-" + System.DateTime.Now.Day + "_" + System.DateTime.Now.Hour + "-" + System.DateTime.Now.Minute + "-" + System.DateTime.Now.Second;
           internalLog = "IRNSS_OFFLINE" + current_system_time_log;
           Directory.CreateDirectory(internalLog);
           int count = 0;
           total_dist_haversine = 0;
           ov.Markers.Clear();
           ov.Routes.Clear();
           MessageBoxUD MB = new MessageBoxUD();
        
           
           while (count < alldata_str.Length)
           {

                   try
                   {


                       string str = "";

                       str = alldata_str[count];
                       NMEA_TOKEN_STR = str.Split(new string[] { ":", "*", ",", "\r", "\n" }, StringSplitOptions.None);
                       if ((NMEA_TOKEN_STR[0] == "ID"))
                       {
                           vehicle_num = NMEA_TOKEN_STR[1];
                           trip_id[id_count] = NMEA_TOKEN_STR[1] + "_" + id_count;
                           entry_count = 0;
                           if (count > 1)
                           {
                               pp_LL.Add(new GMap.NET.PointLatLng(user_Lat_prev, user_Lon_prev));
                           }
                           while (entry_count < alldata_str.Length)
                           {
                               if (count < alldata_str.Length - 1)
                               {
                                   str = alldata_str[count + 1];
                                   NMEA_TOKEN_STR = str.Split(new string[] { ":", "*", ",", "\r", "\n" }, StringSplitOptions.None);

                               }
                               else
                               {
                                   count++; 

                                   break;
                               }

                               if ((NMEA_TOKEN_STR[0] == "ID"))
                               {
                                   count++;
                                   entry_count++;
                                   break;
                               }



                               PARSE_VTUDATA(NMEA_TOKEN_STR, 0);
                               pp_LL.Add(new GMap.NET.PointLatLng(user_Lat, user_Lon));
                               pp_LL_all.Add(new GMap.NET.PointLatLng(user_Lat, user_Lon));

                         
                               if (count > 0)
                               {
                                   total_dist_haversine += dist_cal(user_Lat, user_Lon, user_Lat_prev, user_Lon_prev);
                                 double dist_3d = Math.Sqrt((UX-UX_PREV)*(UX-UX_PREV)+(UY-UY_PREV)*(UY-UY_PREV)+(UZ-UZ_PREV)*(UZ-UZ_PREV));
                                 total_dist_3d += dist_3d;
                                 //Console.WriteLine(NMEA_TOKEN_STR[0] + "," + dist_3d.ToString() + "," + dist_cal(user_Lat, user_Lon, user_Lat_prev, user_Lon_prev).ToString());
                                  
                               }
                              // ov.Markers.Add(new GMap.NET.WindowsForms.Markers.GMapMarkerCross(new GMap.NET.PointLatLng(user_Lat, user_Lon)));
                              
                               if (entry_count == 0)
                               {
                                    string [] byThis2 = str.Split(new string[] { ":", "*", ",", "\r", "\n" }, StringSplitOptions.None);
                                   thisDate = new DateTime(2000 + int.Parse(byThis2[8].Substring(4, 2)), int.Parse(byThis2[8].Substring(2, 2)), int.Parse(byThis2[8].Substring(0, 2)), int.Parse(byThis2[0].Substring(0, 2)), int.Parse(byThis2[0].Substring(2, 2)), int.Parse(byThis2[0].Substring(4, 2)));
                                   thisTime = new DateTimeOffset(thisDate, new TimeSpan(5, 30, 0));
                                   thisDate += thisTime.Offset;
                                   start_time[id_count] = String.Format("{0:00}", thisDate.Day) + "/" + String.Format("{0:00}", thisDate.Month) + "/" + String.Format("{0:0000}", thisDate.Year) + " , " + String.Format("{0:00}", thisDate.Hour) + ":" + String.Format("{0:00}", thisDate.Minute) + ":" + String.Format("{0:00}", thisDate.Second);
                                   gMapControl2.Position = new GMap.NET.PointLatLng(user_Lat, user_Lon);
                                   ov.Markers.Add(new GMap.NET.WindowsForms.Markers.GMapMarkerGoogleGreen(new GMap.NET.PointLatLng(user_Lat, user_Lon)));
                                   gMapControl2.Overlays.Add(ov);
                               }
                               count++;
                               entry_count++;
                           }



                         //  Console.WriteLine(count.ToString() + " , " + entry_count.ToString());

                           if (entry_count > 1)
                           {


                               GMap.NET.MapRoute route = new GMap.NET.MapRoute(pp_LL, "LAT_LON");//= new GMap.NET.MapRoute;
                               GMapRoute r = new GMapRoute(route.Points, "My route");
                               GMapOverlay routesOverlay;// = new GMapOverlay("routes");
                               ov.Routes.Add(r);
                               gMapControl2.Overlays.Add(ov);
                               ov.Markers.Add(new GMap.NET.WindowsForms.Markers.GMapMarkerGoogleRed(new GMap.NET.PointLatLng(user_Lat, user_Lon)));
                               gMapControl2.Overlays.Add(ov);
                               textBox1.Text = ((int)(r.Distance * 100) / 100.0).ToString() + " Km Travelled in this trip.";
                               length_arr[id_count] = r.Distance;
                               total_dist += r.Distance;
                               
                                

                               string temp_str = alldata_str[count - 1];
                               string[] byThis2 = temp_str.Split(new string[] { ":", "*", ",", "\r", "\n" }, StringSplitOptions.None);
                               thisDate = new DateTime(2000 + int.Parse(byThis2[8].Substring(4, 2)), int.Parse(byThis2[8].Substring(2, 2)), int.Parse(byThis2[8].Substring(0, 2)), int.Parse(byThis2[0].Substring(0, 2)), int.Parse(byThis2[0].Substring(2, 2)), int.Parse(byThis2[0].Substring(4, 2)));
                               thisTime = new DateTimeOffset(thisDate, new TimeSpan(5, 30, 0));
                               thisDate += thisTime.Offset;
                               end_time[id_count] = String.Format("{0:00}", thisDate.Day) + "/" + String.Format("{0:00}", thisDate.Month) + "/" + String.Format("{0:0000}", thisDate.Year) + " , " + String.Format("{0:00}", thisDate.Hour) + ":" + String.Format("{0:00}", thisDate.Minute) + ":" + String.Format("{0:00}", thisDate.Second);


                               //MySqlCommand insertCommand = new MySqlCommand("INSERT INTO vtu_data (TRIP_ID, Start_time, End_time, Lat,Lon) VALUES ('" + trip_id[id_count] + "','"+start_time[id_count]+"','"+end_time[id_count]+"','"+user_Lat.ToString()+"','"+user_Lon.ToString()+"')", connection);
                               //insertCommand.ExecuteNonQuery();
                               //trip_image_flag = 0;
                              
                               ov.Markers.Clear();
                               ov.Routes.Clear();
                               pp_LL.Clear();

                               id_count++;
                           }
                           else
                           {
                               ;
                           }






                       }
                       else
                       {
                           count++;
                       }


                   }
                   catch (Exception e1)
                   {
                       continue;
                   }
               
               

           }

           GMap.NET.MapRoute route1 = new GMap.NET.MapRoute(pp_LL_all, "LAT_LON");//= new GMap.NET.MapRoute;
           GMapRoute r1 = new GMapRoute(route1.Points, "My route");
           total_dist_haversine = r1.Distance;                    

           PdfDocument document = new PdfDocument();
           // Create an empty page or load existing

           PdfPage page0 = document.AddPage();
           XGraphics gfx0 = XGraphics.FromPdfPage(page0);

           PdfPage[] page = new PdfPage[10000];
           XGraphics gfx = gfx0;

           XFont font = new XFont("Verdana", 10, XFontStyle.BoldItalic);
           XFont font1 = new XFont("Verdana", 14, XFontStyle.BoldItalic);
           XFont font2 = new XFont("Verdana", 10, XFontStyle.BoldItalic);
           XPen pen1 = new XPen(XColor.FromArgb(Color.Black));

           // Draw the text
          
          
           gfx0.DrawString("Travel Report of Vehicle Number " + vehicle_num, font1, XBrushes.Black, 50,  30);
            gfx0.DrawString("Duration " + start_time[0] + " to " + end_time[id_count - 1] + " (IST)", font1, XBrushes.Black, 50, 50);
           gfx0.DrawString("Total Distance travelled " + ((int)(total_dist*1000)/1000.0).ToString() + "(Km)", font1, XBrushes.Black, 50, 70);
          
         //  gfx0.DrawString("Trip No. \t\t\t\t\t\t\t\t\t\t Start Date \t\t\t Start time \t\t End Date \t\tEnd time \t\t Distance(KM) ", font2, XBrushes.Black, 50, 110);
         
           //gfx0.DrawString("End TOW     = " + end_tow, font, XBrushes.Black, 50, 35);
            int loopcnt = 0;
           for (int i = 0; i < id_count; i++)
           {
               if ((i % 25) == 0)
               {
                  
                   page[loopcnt] = document.AddPage();

                   gfx = XGraphics.FromPdfPage(page[loopcnt]);
                   gfx.DrawString("Trip No. \t\t\t\t\t\t\t\t\t\t Start Date \t\t\t Start time \t\t End Date \t\tEnd time \t\t Distance(KM) ", font2, XBrushes.Black, 50, 50);
                   gfx.DrawRectangle(pen1, 50, 10, 550, 30);

                   loopcnt++;
               }
               gfx.DrawString(trip_id[i] +"\t\t\t\t" + start_time[i] + "\t\t\t" + end_time[i] + "\t\t\t\t\t\t" + ((int)(length_arr[i]*1000)/1000.0).ToString(), font, XBrushes.Black, 50, 70 + 20*(i%25));
           }

           document.Save(vehicle_num + "_" + "Report.pdf");
           Process.Start(vehicle_num + "_" + "Report.pdf");
           //
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Rectangle bounds =   this.Bounds;
            using (Bitmap bitmap = new Bitmap(bounds.Width - splitContainer1.SplitterDistance, bounds.Height))
            {
                using (Graphics g = Graphics.FromImage(bitmap))
                {
                    g.CopyFromScreen(new Point(bounds.Left + splitContainer1.SplitterDistance, bounds.Top), Point.Empty, bounds.Size);
                }
                bitmap.Save("Single_trip.png");
            }

          

        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            timer_2_count++;
            if (timer_2_count > 0)
            {
                Map_image.PerformClick();

                PDF_Generate.PerformClick();
                timer_2_count = 0;
                timer2.Enabled = false;
                trip_image_flag = 0;
            }
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            int file_count = 0;
           
            folderBrowserDialog1.ShowDialog();
            string folder_path = folderBrowserDialog1.SelectedPath;
            string[] filearray = Directory.GetFiles(folder_path);
           
            openFileDialog1.ShowDialog(); 
            string raw_file_path = openFileDialog1.FileName;
            //FileStream fs = new FileStream(raw_file_path, FileMode.Open, FileAccess.ReadWrite, FileShare.Read);
            //  StreamReader w3 = new StreamReader(fs);
            string[] alldata_str = File.ReadAllLines(raw_file_path);
            string current_system_time_log = System.DateTime.Now.Year + "-" + System.DateTime.Now.Month + "-" + System.DateTime.Now.Day + "_" + System.DateTime.Now.Hour + "-" + System.DateTime.Now.Minute + "-" + System.DateTime.Now.Second;
            internalLog = "IRNSS_OFFLINE" + current_system_time_log;
            Directory.CreateDirectory(internalLog);
            int count = 0;
           
            ov.Markers.Clear();
            ov.Routes.Clear();
            MessageBoxUD MB = new MessageBoxUD();


            while (count < alldata_str.Length)
            {

                try
                {


                    string str = "";

                    str = alldata_str[count];
                    NMEA_TOKEN_STR = str.Split(new string[] { ":", "*", ",", "\r", "\n" }, StringSplitOptions.None);
                    if ((NMEA_TOKEN_STR[0] == "ID"))
                    {
                        vehicle_num = NMEA_TOKEN_STR[1];
                        trip_id[id_count] = NMEA_TOKEN_STR[1] + "_" + id_count;
                        entry_count = 0;
                        while (entry_count < alldata_str.Length)
                        {
                            if (count < alldata_str.Length - 1)
                            {
                                str = alldata_str[count + 1];
                                NMEA_TOKEN_STR = str.Split(new string[] { ":", "*", ",", "\r", "\n" }, StringSplitOptions.None);

                            }
                            else
                            {
                                count++;

                                break;
                            }

                            if ((NMEA_TOKEN_STR[0] == "ID"))
                            {
                                count++;
                                entry_count++;
                                break;
                            }

                            PARSE_VTUDATA(NMEA_TOKEN_STR, 0);
                            pp_LL.Add(new GMap.NET.PointLatLng(user_Lat, user_Lon));
                            pp_LL_all.Add(new GMap.NET.PointLatLng(user_Lat, user_Lon));
                         
                          
                            if (entry_count == 0)
                            {
                                string[] byThis2 = str.Split(new string[] { ":", "*", ",", "\r", "\n" }, StringSplitOptions.None);
                                thisDate = new DateTime(2000 + int.Parse(byThis2[8].Substring(4, 2)), int.Parse(byThis2[8].Substring(2, 2)), int.Parse(byThis2[8].Substring(0, 2)), int.Parse(byThis2[0].Substring(0, 2)), int.Parse(byThis2[0].Substring(2, 2)), int.Parse(byThis2[0].Substring(4, 2)));
                                thisTime = new DateTimeOffset(thisDate, new TimeSpan(5, 30, 0));
                                thisDate += thisTime.Offset;
                                start_time[id_count] = String.Format("{0:00}", thisDate.Day) + "/" + String.Format("{0:00}", thisDate.Month) + "/" + String.Format("{0:0000}", thisDate.Year) + " , " + String.Format("{0:00}", thisDate.Hour) + ":" + String.Format("{0:00}", thisDate.Minute) + ":" + String.Format("{0:00}", thisDate.Second);
                                gMapControl2.Position = new GMap.NET.PointLatLng(user_Lat, user_Lon);
                                GMapMarker g1 = new GMap.NET.WindowsForms.Markers.GMapMarkerGoogleGreen(new GMap.NET.PointLatLng(user_Lat, user_Lon));
                                MarkerTooltipMode mode = MarkerTooltipMode.Always;
                                g1.ToolTipMode = mode;
                                g1.ToolTip = new GMapToolTip(g1);
                                //g1.ToolTipText = "Start\r\n" + start_time[id_count];
                                ov.Markers.Add(g1);//new GMap.NET.WindowsForms.Markers.GMapMarkerGoogleGreen(new GMap.NET.PointLatLng(user_Lat, user_Lon)));
                              
                                gMapControl2.Overlays.Add(ov);
                            }
                            count++;
                            entry_count++;
                        }



                       // Console.WriteLine(count.ToString() + " , " + entry_count.ToString());

                        if (entry_count > 1)
                        {


                            GMap.NET.MapRoute route = new GMap.NET.MapRoute(pp_LL, "LAT_LON");//= new GMap.NET.MapRoute;
                            GMapRoute r = new GMapRoute(route.Points, "My route");
                            GMapOverlay routesOverlay;// = new GMapOverlay("routes");
                            ov.Routes.Add(r);
                            gMapControl2.Overlays.Add(ov);

                          textBox1.Text = ((int)(r.Distance * 100) / 100.0).ToString() + " Km Travelled in this trip.";
                            length_arr[id_count] = r.Distance;
                            total_dist += r.Distance;
                           
                            string temp_str = alldata_str[count - 1];
                            string[] byThis2 = temp_str.Split(new string[] { ":", "*", ",", "\r", "\n" }, StringSplitOptions.None);
                            thisDate = new DateTime(2000 + int.Parse(byThis2[8].Substring(4, 2)), int.Parse(byThis2[8].Substring(2, 2)), int.Parse(byThis2[8].Substring(0, 2)), int.Parse(byThis2[0].Substring(0, 2)), int.Parse(byThis2[0].Substring(2, 2)), int.Parse(byThis2[0].Substring(4, 2)));
                            thisTime = new DateTimeOffset(thisDate, new TimeSpan(5, 30, 0));
                            thisDate += thisTime.Offset;
                            end_time[id_count] = String.Format("{0:00}", thisDate.Day) + "/" + String.Format("{0:00}", thisDate.Month) + "/" + String.Format("{0:0000}", thisDate.Year) + " , " + String.Format("{0:00}", thisDate.Hour) + ":" + String.Format("{0:00}", thisDate.Minute) + ":" + String.Format("{0:00}", thisDate.Second);

                            GMapMarker g2 = new GMap.NET.WindowsForms.Markers.GMapMarkerGoogleRed(new GMap.NET.PointLatLng(user_Lat, user_Lon));
                            MarkerTooltipMode mode = MarkerTooltipMode.Always;
                            g2.ToolTipMode = mode;
                            g2.ToolTip = new GMapToolTip(g2);
                            //g2.ToolTipText = "END \r\n" + end_time[id_count];
                            ov.Markers.Add(g2);//new GMap.NET.WindowsForms.Markers.GMapMarkerGoogleGreen(new GMap.NET.PointLatLng(user_Lat, user_Lon)));

                            // ov.Markers.Add(new GMap.NET.WindowsForms.Markers.GMapMarkerGoogleRed(new GMap.NET.PointLatLng(user_Lat, user_Lon)));
                            gMapControl2.Overlays.Add(ov);
                         



                            str = alldata_str[(int)(entry_count/2)];
                            NMEA_TOKEN_STR = str.Split(new string[] { ":", "*", ",", "\r", "\n" }, StringSplitOptions.None);
                   
                            PARSE_VTUDATA(NMEA_TOKEN_STR, 0);
                           gMapControl2.Position =  new GMap.NET.PointLatLng(user_Lat, user_Lon);
                           GMap.NET.RectLatLng? r2 = gMapControl2.GetRectOfAllRoutes("OverlayOne");
                          gMapControl2.SetZoomToFitRect(r2.Value );

                            id_count++;

                            trip_image_flag = 0;
                            timer2.Enabled = true;
                        }
                        else
                        {
                            MessageBox.Show("No Data points in this trip");
                        }


 



                    }
                    else
                    {
                        count++;
                    }


                }
                catch (Exception e1)
                {
                    ;
                }



            }

            GMap.NET.MapRoute route1 = new GMap.NET.MapRoute(pp_LL_all, "LAT_LON");//= new GMap.NET.MapRoute;
            GMapRoute r1 = new GMapRoute(route1.Points, "My route");
            total_dist = r1.Distance;
           
           

         
            //
        }

        private void button6_Click(object sender, EventArgs e)
        {
            PdfDocument document = new PdfDocument();
            // Create an empty page or load existing

            PdfPage page0 = document.AddPage();
            XGraphics gfx0 = XGraphics.FromPdfPage(page0);

            PdfPage[] page = new PdfPage[10000];
            XGraphics gfx = gfx0;

            XFont font = new XFont("Verdana", 10, XFontStyle.BoldItalic);
            XFont font1 = new XFont("Verdana", 14, XFontStyle.BoldItalic);
            XFont font2 = new XFont("Verdana", 10, XFontStyle.BoldItalic);

            string[] reportname = openFileDialog1.FileName.Split(new string[] { "\\", ".", ",", "\r", "\n" }, StringSplitOptions.None);
           
            // Draw the text
            gfx0.DrawString("Trip details " + reportname[reportname.Length - 2], font1, XBrushes.Black, 50, 30);
            gfx0.DrawString("Duration " + start_time[0] + " to " + end_time[id_count-1] + " (IST)", font1, XBrushes.Black, 50, 50);
            gfx0.DrawString("Total Distance travelled " + ((int)(total_dist * 100) / 100.0).ToString() + "(Km)", font1, XBrushes.Black, 50, 70);

            gfx0.DrawString("Vehicle No. \t\t\t Start Date \t\t\t Start time \t\t\t End Date \t\t\t End time \t\t\t Distance(KM) ", font2, XBrushes.Black, 50, 110);

            //gfx0.DrawString("End TOW     = " + end_tow, font, XBrushes.Black, 50, 35);
            int loopcnt = 0;
            for (int i = 0; i < id_count; i++)
            {
                //if ((i % 2) == 0)
                //{
                //    page[loopcnt] = document.AddPage();
                //    gfx = XGraphics.FromPdfPage(page[loopcnt]);

                //        loopcnt++;
                //}
                gfx.DrawString(trip_id[i] + "\t\t\t" + start_time[i] + "\t\t\t" + end_time[i] + "\t\t\t\t\t\t" + ((int)(length_arr[i] * 100) / 100.0).ToString(), font, XBrushes.Black, 50, 130 + 20 * i);
            }
            string[] image_file_array = new string[100];
            image_file_array[0] = "Single_trip.png";
            gfx.DrawString("Map View", font, XBrushes.Black, 50, 200);
            DrawImage(gfx, image_file_array[0], 50, 220, 500, 250);
            string [] start_id = start_time[0].Split(new string[] { "/", ".", ",", ":", "\n" }, StringSplitOptions.None);

            document.Save(reportname[reportname.Length - 2] + start_id[0] + "_" + start_id[1] + "_" + start_id[2] + "_" + start_id[3] + "_" + start_id[4] + "_" + start_id[5] + "_" + "Report.pdf");
            Process.Start(reportname[reportname.Length - 2] + start_id[0] + "_" + start_id[1] + "_" + start_id[2] + "_" + start_id[3] + "_" + start_id[4] + "_" + start_id[5] + "_" + "Report.pdf");
        }

        void DrawImage(XGraphics gfx, string jpegSamplePath, int x, int y, int width, int height)
        {
            XImage image = XImage.FromFile(jpegSamplePath);
            gfx.DrawImage(image, x, y, width, height);
        } 

        private void gMapControl2_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            textBox1.Text = gMapControl2.Zoom.ToString();
        }

        private void portname_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            if (global_cnt == 0)
            {
                openFileDialog1.ShowDialog();
                 raw_file_path_G = openFileDialog1.FileName;
                //FileStream fs = new FileStream(raw_file_path, FileMode.Open, FileAccess.ReadWrite, FileShare.Read);
                //  StreamReader w3 = new StreamReader(fs);
                 alldata_str_G = File.ReadAllLines(raw_file_path_G);

                 timer3.Enabled = true;
            }

            global_cnt++;    
                try
                {
                    string str = "";

                    str = alldata_str_G[global_cnt];
                    NMEA_TOKEN_STR = str.Split(new string[] { ":", "*", ",", "\r", "\n" }, StringSplitOptions.None);
                    PARSE_VTUDATA(NMEA_TOKEN_STR, 0);
                    GMapMarker g2 = new GMap.NET.WindowsForms.Markers.GMapMarkerGoogleGreen(new GMap.NET.PointLatLng(user_Lat, user_Lon));
                    MarkerTooltipMode mode1 = MarkerTooltipMode.Always;
                    //g2.ToolTipMode = mode1;
                    //g2.ToolTip = new GMapToolTip(g2);
                    //if ((global_cnt % 2) == 0)
                    //{
                    //    g2.ToolTipText = "Start" + global_cnt.ToString() + "," + NMEA_TOKEN_STR[0] + "," + NMEA_TOKEN_STR[10];
                    //}
                    //else
                    //{
                    //    g2.ToolTipText = "Stop" + global_cnt.ToString() + "," + NMEA_TOKEN_STR[0] + "," + NMEA_TOKEN_STR[10];
                    //}

                    ov.Markers.Add(g2);//new GMap.NET.WindowsForms.Markers.GMapMarkerGoogleGreen(new GMap.NET.PointLatLng(user_Lat, user_Lon)));
                    gMapControl2.Overlays.Add(ov);
                    gMapControl2.Position = new GMap.NET.PointLatLng(user_Lat, user_Lon);
                    


                }
                catch (Exception e1)
                {
                    ;
                }




          
        }

        private void clear_map_Click(object sender, EventArgs e)
        {
            ov.Markers.Clear();
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            plot_map.PerformClick();
        }

        private void button4_Click_2(object sender, EventArgs e)
        {
            server = "127.0.0.1";
            database = "test";
            uid = "root";
            password = "";
            string connectionString;
            connectionString = "SERVER=" + server + ";" + "DATABASE=" +
            database + ";" + "UID=" + uid + ";" + "PASSWORD=" + password + ";" + "CharSet = utf8";

            connection = new MySqlConnection(connectionString);

            try
            {
                connection.Open();
                MySqlCommand SqlCommand = new MySqlCommand("SELECT * FROM vtu_data WHERE 1", connection);
                
              // MessageBox.Show(SqlCommand.ToString());

                using (MySqlDataReader reader = SqlCommand.ExecuteReader()) 
                {
                    Console.WriteLine("FirstColumn\tSecond Column\t\tThird Column\t\tForth Column\t");
                    while (reader.Read())
                    {
                        Console.WriteLine(String.Format("{0} \t | {1} \t | {2} \t | {3} \t | {4}",
                            reader[0], reader[1], reader[2], reader[3], reader[4]));
                    }
                }

              
            }
            catch (MySqlException ex)
            {
                //When handling errors, you can your application's response based 
                //on the error number.
                //The two most common error numbers when connecting are as follows:
                //0: Cannot connect to server.
                //1045: Invalid user name and/or password.
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot connect to server.  Contact administrator");
                        break;

                    case 1045:
                        MessageBox.Show("Invalid username/password, please try again");
                        break;
                }
                 
            }
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            // CheckForIllegalCrossThreadCalls = false;
            string current_system_time_log = System.DateTime.Now.Year + "-" + System.DateTime.Now.Month + "-" + System.DateTime.Now.Day + "_" + System.DateTime.Now.Hour + "-" + System.DateTime.Now.Minute + "-" + System.DateTime.Now.Second;
            internalLog = "IRNSS" + current_system_time_log;
            Directory.CreateDirectory(internalLog);
            filepath_raw = internalLog + "\\raw_data.csv";
          

            openFileDialog1.ShowDialog();
            string raw_file_path = openFileDialog1.FileName;
            string[] alldata_str = File.ReadAllLines(raw_file_path);
         

            int log_count = 0;
            double line_count = 0;
            //textBox2.Text = "";
            // textBox2.Text = current_system_time_log +" Reading Start\r\n";
            timer1.Enabled = true;
            int cnt = 0;
            while (true)
            {
                Stop_flag = 0;

                // current_system_time_log = System.DateTime.Now.Year + "-" + System.DateTime.Now.Month + "-" + System.DateTime.Now.Day + "_" + System.DateTime.Now.Hour + "-" + System.DateTime.Now.Minute + "-" + System.DateTime.Now.Second;


                try
                {

                    
                    {
                        str = alldata_str[cnt++];
                        string[] byThis = str.Split(new string[] { ":", "\r" }, StringSplitOptions.RemoveEmptyEntries);
                        string[] byThis2 = str.Split(new string[] { ":", "\r" }, StringSplitOptions.RemoveEmptyEntries);
                        line_count++;
                        //Console.WriteLine(str);
                        if (byThis[0] == "ID")
                        {
                            //str = COM_OUT.ReadLine();
                            filepath_vehicle = internalLog + "\\" + byThis[1] + "_" + log_count.ToString() + ".csv";
                            log_count++;
                            line_count--;
                        }

                        textBox2.Text = str;

                        if (str == "END\r")
                        {
                            //char_buf = "#,OVER,$";
                            //char_arr = char_buf.ToCharArray();
                            //send_data_flag = 1;
                            //COM_OUT.Write(char_arr, 0, char_arr.Length);
                            timer1.Enabled = false;
                            COM_OUT.BaudRate = 9600;
                            //timer1.Enabled = false;
                            current_system_time_log = System.DateTime.Now.Year + "-" + System.DateTime.Now.Month + "-" + System.DateTime.Now.Day + "_" + System.DateTime.Now.Hour + "-" + System.DateTime.Now.Minute + "-" + System.DateTime.Now.Second;
                            double time = (line_count * 5) / 60;
                            int time_min = (int)(time * 100);
                            time = time_min / 100.0;
                            textBox2.Text = time.ToString() + " minutes Data Read Successfully \r\n";


                            break;
                        }

                        using (w2 = File.AppendText(filepath_raw))
                        {
                            w2.WriteLine(str);
                            w2.Close();
                        }

                        using (w2 = File.AppendText(filepath_vehicle))
                        {
                            w2.WriteLine(str);
                            w2.Close();
                        }




                    }

                }
                catch (Exception e1)
                {
                    ;
                }
            }

            
            MessageBox.Show("File read successfully");
            button1.PerformClick();
            // Application.Exit();

        }

        private void button7_Click(object sender, EventArgs e)
        {
            server = "127.0.0.1";
            database = "test";
            uid = "root";
            password = "";
            string connectionString;
            connectionString = "SERVER=" + server + ";" + "DATABASE=" +
            database + ";" + "UID=" + uid + ";" + "PASSWORD=" + password + ";" + "CharSet = utf8";

            connection = new MySqlConnection(connectionString);

            try
            {
                connection.Open();
               int insert_cnt = 0;
                while (insert_cnt < 1000000)
                {
                    MySqlCommand insertCommand = new MySqlCommand("INSERT INTO vtu_data (TRIP_ID, Start_time, End_time, Lat,Lon) VALUES ('" + insert_cnt.ToString() + "','" + "A" + "','" + "B" + "','" + "C" + "','" + "D" + "')", connection);
                    insertCommand.ExecuteNonQuery();
                    insert_cnt++;
                    if((insert_cnt%10000) == 0)
                    {
                        Console.WriteLine("inserted " + insert_cnt.ToString() + "Record");
                    }
                }

                


            }
            catch (MySqlException ex)
            {
                //When handling errors, you can your application's response based 
                //on the error number.
                //The two most common error numbers when connecting are as follows:
                //0: Cannot connect to server.
                //1045: Invalid user name and/or password.
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot connect to server.  Contact administrator");
                        break;

                    case 1045:
                        MessageBox.Show("Invalid username/password, please try again");
                        break;
                }

            }
           
        }

        private void portname_cb_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}

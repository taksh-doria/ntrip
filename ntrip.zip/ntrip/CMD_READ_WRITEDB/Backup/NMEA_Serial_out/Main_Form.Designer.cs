﻿namespace NMEA_Serial_out
{
    partial class NMEA_OUT
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.COM_OUT = new System.IO.Ports.SerialPort(this.components);
            this.button2 = new System.Windows.Forms.Button();
            this.handshake_cb = new System.Windows.Forms.ComboBox();
            this.Handshake_1 = new System.Windows.Forms.Label();
            this.parity_cb = new System.Windows.Forms.ComboBox();
            this.stopbits_cb = new System.Windows.Forms.ComboBox();
            this.databits_cb = new System.Windows.Forms.ComboBox();
            this.baudrate_cb = new System.Windows.Forms.ComboBox();
            this.portname_cb = new System.Windows.Forms.ComboBox();
            this.Parity_1 = new System.Windows.Forms.Label();
            this.Stopbits = new System.Windows.Forms.Label();
            this.Databits = new System.Windows.Forms.Label();
            this.Baudrate = new System.Windows.Forms.Label();
            this.portname = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.RemovFile = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SendMail = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.clear_map = new System.Windows.Forms.Button();
            this.plot_map = new System.Windows.Forms.Button();
            this.gMapControl2 = new GMap.NET.WindowsForms.GMapControl();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.Map_image = new System.Windows.Forms.Button();
            this.PDF_Generate = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.statusStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button2
            // 
            this.button2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.Teal;
            this.button2.Location = new System.Drawing.Point(3, 214);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(247, 49);
            this.button2.TabIndex = 1;
            this.button2.Text = "Complete Data";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // handshake_cb
            // 
            this.handshake_cb.FormattingEnabled = true;
            this.handshake_cb.Items.AddRange(new object[] {
            "None",
            "XOnXOff",
            "RequestToSend",
            "RequestToSendXOnXOff"});
            this.handshake_cb.Location = new System.Drawing.Point(63, 191);
            this.handshake_cb.Name = "handshake_cb";
            this.handshake_cb.Size = new System.Drawing.Size(79, 21);
            this.handshake_cb.TabIndex = 19;
            this.handshake_cb.Visible = false;
            // 
            // Handshake_1
            // 
            this.Handshake_1.AutoSize = true;
            this.Handshake_1.Location = new System.Drawing.Point(-3, 194);
            this.Handshake_1.Name = "Handshake_1";
            this.Handshake_1.Size = new System.Drawing.Size(62, 13);
            this.Handshake_1.TabIndex = 18;
            this.Handshake_1.Text = "Handshake";
            this.Handshake_1.Visible = false;
            // 
            // parity_cb
            // 
            this.parity_cb.FormattingEnabled = true;
            this.parity_cb.Items.AddRange(new object[] {
            "None",
            "Odd",
            "Even",
            "Mark",
            "Space"});
            this.parity_cb.Location = new System.Drawing.Point(63, 165);
            this.parity_cb.Name = "parity_cb";
            this.parity_cb.Size = new System.Drawing.Size(79, 21);
            this.parity_cb.TabIndex = 15;
            this.parity_cb.Visible = false;
            // 
            // stopbits_cb
            // 
            this.stopbits_cb.FormattingEnabled = true;
            this.stopbits_cb.Items.AddRange(new object[] {
            "None",
            "One",
            "OnePointFive",
            "Two"});
            this.stopbits_cb.Location = new System.Drawing.Point(63, 138);
            this.stopbits_cb.Name = "stopbits_cb";
            this.stopbits_cb.Size = new System.Drawing.Size(79, 21);
            this.stopbits_cb.TabIndex = 16;
            this.stopbits_cb.Visible = false;
            // 
            // databits_cb
            // 
            this.databits_cb.FormattingEnabled = true;
            this.databits_cb.Items.AddRange(new object[] {
            "4",
            "5",
            "6",
            "7",
            "8",
            "9"});
            this.databits_cb.Location = new System.Drawing.Point(60, 86);
            this.databits_cb.Name = "databits_cb";
            this.databits_cb.Size = new System.Drawing.Size(82, 21);
            this.databits_cb.TabIndex = 17;
            this.databits_cb.Visible = false;
            // 
            // baudrate_cb
            // 
            this.baudrate_cb.FormattingEnabled = true;
            this.baudrate_cb.Items.AddRange(new object[] {
            "75",
            "110",
            "134",
            "150",
            "300",
            "600",
            "1200",
            "1800",
            "2400",
            "4800",
            "9600",
            "14400",
            "19200",
            "38400",
            "57600",
            "115200",
            "128000"});
            this.baudrate_cb.Location = new System.Drawing.Point(60, 109);
            this.baudrate_cb.Name = "baudrate_cb";
            this.baudrate_cb.Size = new System.Drawing.Size(82, 21);
            this.baudrate_cb.TabIndex = 13;
            this.baudrate_cb.Visible = false;
            // 
            // portname_cb
            // 
            this.portname_cb.Dock = System.Windows.Forms.DockStyle.Fill;
            this.portname_cb.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.portname_cb.FormattingEnabled = true;
            this.portname_cb.Location = new System.Drawing.Point(3, 38);
            this.portname_cb.Name = "portname_cb";
            this.portname_cb.Size = new System.Drawing.Size(247, 32);
            this.portname_cb.TabIndex = 14;
            // 
            // Parity_1
            // 
            this.Parity_1.AutoSize = true;
            this.Parity_1.Location = new System.Drawing.Point(12, 168);
            this.Parity_1.Name = "Parity_1";
            this.Parity_1.Size = new System.Drawing.Size(33, 13);
            this.Parity_1.TabIndex = 9;
            this.Parity_1.Text = "Parity";
            this.Parity_1.Visible = false;
            // 
            // Stopbits
            // 
            this.Stopbits.AutoSize = true;
            this.Stopbits.Location = new System.Drawing.Point(6, 141);
            this.Stopbits.Name = "Stopbits";
            this.Stopbits.Size = new System.Drawing.Size(44, 13);
            this.Stopbits.TabIndex = 8;
            this.Stopbits.Text = "Stop Bit";
            this.Stopbits.Visible = false;
            // 
            // Databits
            // 
            this.Databits.AutoSize = true;
            this.Databits.Location = new System.Drawing.Point(0, 89);
            this.Databits.Name = "Databits";
            this.Databits.Size = new System.Drawing.Size(50, 13);
            this.Databits.TabIndex = 10;
            this.Databits.Text = "Data Bits";
            this.Databits.Visible = false;
            // 
            // Baudrate
            // 
            this.Baudrate.AutoSize = true;
            this.Baudrate.Location = new System.Drawing.Point(0, 112);
            this.Baudrate.Name = "Baudrate";
            this.Baudrate.Size = new System.Drawing.Size(50, 13);
            this.Baudrate.TabIndex = 12;
            this.Baudrate.Text = "Baudrate";
            this.Baudrate.Visible = false;
            // 
            // portname
            // 
            this.portname.AutoSize = true;
            this.portname.Dock = System.Windows.Forms.DockStyle.Fill;
            this.portname.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.portname.Location = new System.Drawing.Point(3, 0);
            this.portname.Name = "portname";
            this.portname.Size = new System.Drawing.Size(247, 35);
            this.portname.TabIndex = 11;
            this.portname.Text = "COM PORT";
            this.portname.Click += new System.EventHandler(this.portname_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 529);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1217, 22);
            this.statusStrip1.TabIndex = 25;
            this.statusStrip1.Text = "Developed by SNTD/DCTG/SNAA";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(337, 17);
            this.toolStripStatusLabel1.Text = "                                        Developed by NAD/NTAG/SSAA              ";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // RemovFile
            // 
            this.RemovFile.Dock = System.Windows.Forms.DockStyle.Fill;
            this.RemovFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RemovFile.ForeColor = System.Drawing.Color.Teal;
            this.RemovFile.Location = new System.Drawing.Point(3, 164);
            this.RemovFile.Name = "RemovFile";
            this.RemovFile.Size = new System.Drawing.Size(247, 44);
            this.RemovFile.TabIndex = 26;
            this.RemovFile.Text = "Last Trip Data";
            this.RemovFile.UseVisualStyleBackColor = true;
            this.RemovFile.Click += new System.EventHandler(this.RemovFile_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Teal;
            this.button1.Location = new System.Drawing.Point(100, 26);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(62, 29);
            this.button1.TabIndex = 28;
            this.button1.Text = "View Log Folder";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // SendMail
            // 
            this.SendMail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SendMail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SendMail.ForeColor = System.Drawing.Color.Teal;
            this.SendMail.Location = new System.Drawing.Point(3, 269);
            this.SendMail.Name = "SendMail";
            this.SendMail.Size = new System.Drawing.Size(247, 49);
            this.SendMail.TabIndex = 29;
            this.SendMail.Text = "Send Mail";
            this.SendMail.UseVisualStyleBackColor = true;
            this.SendMail.Click += new System.EventHandler(this.SendMail_Click);
            // 
            // button3
            // 
            this.button3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.Teal;
            this.button3.Location = new System.Drawing.Point(3, 75);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(247, 37);
            this.button3.TabIndex = 30;
            this.button3.Text = " Complete Report";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = global::NMEA_Serial_out.Properties.Resources.SAC_LOGO;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(93, 6);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(84, 74);
            this.pictureBox2.TabIndex = 24;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::NMEA_Serial_out.Properties.Resources.ISRO_LOGO;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(3, 8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(84, 78);
            this.pictureBox1.TabIndex = 23;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button7);
            this.groupBox1.Controls.Add(this.button6);
            this.groupBox1.Controls.Add(this.button4);
            this.groupBox1.Controls.Add(this.clear_map);
            this.groupBox1.Controls.Add(this.plot_map);
            this.groupBox1.Controls.Add(this.gMapControl2);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(960, 529);
            this.groupBox1.TabIndex = 31;
            this.groupBox1.TabStop = false;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(106, 106);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 23);
            this.button7.TabIndex = 128;
            this.button7.Text = "button7";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(354, 30);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 127;
            this.button6.Text = "file_split";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click_1);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(198, 26);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(104, 28);
            this.button4.TabIndex = 126;
            this.button4.Text = "button4";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click_2);
            // 
            // clear_map
            // 
            this.clear_map.Location = new System.Drawing.Point(106, 20);
            this.clear_map.Name = "clear_map";
            this.clear_map.Size = new System.Drawing.Size(75, 23);
            this.clear_map.TabIndex = 125;
            this.clear_map.Text = "clear all";
            this.clear_map.UseVisualStyleBackColor = true;
            this.clear_map.Click += new System.EventHandler(this.clear_map_Click);
            // 
            // plot_map
            // 
            this.plot_map.Location = new System.Drawing.Point(24, 19);
            this.plot_map.Name = "plot_map";
            this.plot_map.Size = new System.Drawing.Size(75, 23);
            this.plot_map.TabIndex = 124;
            this.plot_map.Text = "plot";
            this.plot_map.UseVisualStyleBackColor = true;
            this.plot_map.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // gMapControl2
            // 
            this.gMapControl2.Bearing = 0F;
            this.gMapControl2.CanDragMap = true;
            this.gMapControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gMapControl2.GrayScaleMode = false;
            this.gMapControl2.LevelsKeepInMemmory = 5;
            this.gMapControl2.Location = new System.Drawing.Point(3, 16);
            this.gMapControl2.MarkersEnabled = true;
            this.gMapControl2.MaxZoom = 2;
            this.gMapControl2.MinZoom = 2;
            this.gMapControl2.MouseWheelZoomType = GMap.NET.MouseWheelZoomType.MousePositionAndCenter;
            this.gMapControl2.Name = "gMapControl2";
            this.gMapControl2.NegativeMode = false;
            this.gMapControl2.PolygonsEnabled = true;
            this.gMapControl2.RetryLoadTile = 0;
            this.gMapControl2.RoutesEnabled = true;
            this.gMapControl2.ShowTileGridLines = false;
            this.gMapControl2.Size = new System.Drawing.Size(954, 510);
            this.gMapControl2.TabIndex = 123;
            this.gMapControl2.Zoom = 0;
            this.gMapControl2.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.gMapControl2_MouseDoubleClick);
            // 
            // textBox1
            // 
            this.textBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(3, 365);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(247, 29);
            this.textBox1.TabIndex = 124;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.tableLayoutPanel1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.groupBox1);
            this.splitContainer1.Size = new System.Drawing.Size(1217, 529);
            this.splitContainer1.SplitterDistance = 253;
            this.splitContainer1.TabIndex = 32;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.SendMail, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.Map_image, 0, 10);
            this.tableLayoutPanel1.Controls.Add(this.PDF_Generate, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.textBox1, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.button2, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.textBox2, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.RemovFile, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.button5, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.button3, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.portname_cb, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.portname, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 11;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 37F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 43F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 46F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 55F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 55F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 41F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 42F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 48F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(253, 529);
            this.tableLayoutPanel1.TabIndex = 127;
            // 
            // Map_image
            // 
            this.Map_image.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Map_image.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Map_image.ForeColor = System.Drawing.Color.Teal;
            this.Map_image.Location = new System.Drawing.Point(3, 442);
            this.Map_image.Name = "Map_image";
            this.Map_image.Size = new System.Drawing.Size(247, 84);
            this.Map_image.TabIndex = 125;
            this.Map_image.Text = "Map_image";
            this.Map_image.UseVisualStyleBackColor = true;
            this.Map_image.Click += new System.EventHandler(this.button4_Click);
            // 
            // PDF_Generate
            // 
            this.PDF_Generate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PDF_Generate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PDF_Generate.ForeColor = System.Drawing.Color.Teal;
            this.PDF_Generate.Location = new System.Drawing.Point(3, 400);
            this.PDF_Generate.Name = "PDF_Generate";
            this.PDF_Generate.Size = new System.Drawing.Size(247, 36);
            this.PDF_Generate.TabIndex = 125;
            this.PDF_Generate.Text = "PDF_Generate";
            this.PDF_Generate.UseVisualStyleBackColor = true;
            this.PDF_Generate.Click += new System.EventHandler(this.button6_Click);
            // 
            // textBox2
            // 
            this.textBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox2.Location = new System.Drawing.Point(3, 324);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(247, 35);
            this.textBox2.TabIndex = 21;
            // 
            // button5
            // 
            this.button5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.Teal;
            this.button5.Location = new System.Drawing.Point(3, 118);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(247, 40);
            this.button5.TabIndex = 126;
            this.button5.Text = "Tripwise Report";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // timer2
            // 
            this.timer2.Interval = 1000;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // timer3
            // 
            this.timer3.Interval = 50;
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // NMEA_OUT
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1217, 551);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.handshake_cb);
            this.Controls.Add(this.Handshake_1);
            this.Controls.Add(this.parity_cb);
            this.Controls.Add(this.stopbits_cb);
            this.Controls.Add(this.databits_cb);
            this.Controls.Add(this.baudrate_cb);
            this.Controls.Add(this.Parity_1);
            this.Controls.Add(this.Stopbits);
            this.Controls.Add(this.Databits);
            this.Controls.Add(this.Baudrate);
            this.MaximumSize = new System.Drawing.Size(5002, 5000);
            this.MinimumSize = new System.Drawing.Size(300, 300);
            this.Name = "NMEA_OUT";
            this.Text = "VTU Data Reader";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.NMEA_OUT_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.IO.Ports.SerialPort COM_OUT;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ComboBox handshake_cb;
        private System.Windows.Forms.Label Handshake_1;
        private System.Windows.Forms.ComboBox parity_cb;
        private System.Windows.Forms.ComboBox stopbits_cb;
        private System.Windows.Forms.ComboBox databits_cb;
        private System.Windows.Forms.ComboBox baudrate_cb;
        private System.Windows.Forms.ComboBox portname_cb;
        private System.Windows.Forms.Label Parity_1;
        private System.Windows.Forms.Label Stopbits;
        private System.Windows.Forms.Label Databits;
        private System.Windows.Forms.Label Baudrate;
        private System.Windows.Forms.Label portname;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button RemovFile;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button SendMail;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.GroupBox groupBox1;
        private GMap.NET.WindowsForms.GMapControl gMapControl2;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button Map_image;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button PDF_Generate;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button plot_map;
        private System.Windows.Forms.Button clear_map;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
    }
}


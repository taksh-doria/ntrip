﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace serial_port
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            getavailableports();
        }
        void getavailable ports()
        {
            string[] ports= Serialport.GetportNames();
            comboBox1.Items.AddRange(ports);

        }
        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
          {
             if   (comboBox1.Text==""||comboBox2.Text=="")
             {
                 textBox2.Text="please select port settings";
             }
             else
             {
                 serialport1.portname=comboBox1.Text;
                 serialport1.baudrate=Convert.ToInt32(comboBox2.Text);
                 serialport1.Open();
                 progressBar1.Value=100;
                 button1.Enabled=true;
                 button2.Enabled=true;
                 textBox1.Enabled=true;
                 button3.Enabled=false;
                 button4.Enabled=true;
             }
          }
                catch(UnauthorizedAccessException)
                {
                    textBox2.Text="unauthorized access";
                }
             }
        }
          
    }


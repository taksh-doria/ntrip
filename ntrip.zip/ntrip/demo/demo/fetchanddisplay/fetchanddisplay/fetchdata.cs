﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Data.SqlClient;



namespace fetchanddisplay
{
    public partial class Form1 : Form
    {
        MySqlConnection conn1 = new MySqlConnection(@"Datasource=localhost;port=3306;Userid=root;Password=");
        MySqlDataAdapter da;
        DataTable dt;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
          MySqlConnection conn1 = new MySqlConnection(@"Datasource=localhost;port=3306;Initial catlog=Sample_table;Userid=root;Password=");
           //MySqlConnection conn1 = new MySqlConnection("Data Source=.;Initial Catalog=root;Integrated Security=True");
            conn1.Open();
            MySqlCommand cmd = new MySqlCommand("Select Id,Username,Password,Mobile_no from Sample_table where Id=@Id", conn1);
            cmd.Parameters.AddWithValue("Id", textBox1.Text);
           MySqlDataReader.Reader1;
            Reader1 = cmd.ExecuteReader();
            if
            {
                textBox2.Text=Reader1["Username"]ToString();
                textBox3.Text=Reader1["Password"]ToString();
                textBox4.Text=Reader1["Mobile_no"]ToString();
            }
            else
            {
                MessageBox.Show("no data found");

            }
            conn1.Close();
        }
            */
            da = new MySqlDataAdapter("select*from Sample_table", conn1);
            dt = new DataTable();
            da.Fill(dt);
         dataGridView1.Datasource = dt;
           dataGridView1.DataBind();
        
        }
    }
}

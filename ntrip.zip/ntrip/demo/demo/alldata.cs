﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient; 

namespace demo
{
    public partial class Form1 : Form
    {
        MySqlConnection connection;
         
         string server;
         string database;
         string uid;
         string password;

        public Form1()
        {
            
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            server = "127.0.0.1";
            database = "navic databases";
            uid = "root";
            password = " ";
            string connectionString;
            connectionString = "SERVER=" + server + ";" + "DATABASE=" +
            database + ";" + "UID=" + uid + ";" + "PASSWORD=" + password + ";" + "CharSet = utf8";

            connection = new MySqlConnection(connectionString);

            try
            {
                connection.Open();
                int insert_cnt = 0;
                while (insert_cnt < 1000000)
                {
                    MySqlCommand insertCommand = new MySqlCommand("INSERT INTO sample_table (Id, Username, Password,Mobile_no) VALUES ('" + "A" + "','" + "B" + "','" + "C" + "','" + "D" + "')", connection);
                    insertCommand.ExecuteNonQuery();
                    insert_cnt++;
                    if ((insert_cnt % 10000) == 0)
                    {
                        Console.WriteLine("inserted " + insert_cnt.ToString() + "Record");
                    }
                }
            }
            catch (MySqlException ex)
            {
                //When handling errors, you can your application's response based 
                //on the error number.
                //The two most common error numbers when connecting are as follows:
                //0: Cannot connect to server.
                //1045: Invalid user name and/or password.
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot connect to server.  Contact administrator");
                        break;

                    case 1045:
                        MessageBox.Show("Invalid username/password, please try again");
                        break;
                }
            }
        }
          
     /*con.Open();
            MySqlCommand cmd= con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText="insert into sample_table values '+textBox1.Text' ";
          
           con.Close();
        }
*/

        private void button2_Click(object sender, EventArgs e)
        {
            server = "127.0.0.1";
            database = "navic databases";
            uid = "root";
            password = "";
            string connectionString;
            connectionString = "SERVER=" + server + ";" + "DATABASE=" +
            database + ";" + "UID=" + uid + ";" + "PASSWORD=" + password + ";" + "CharSet = utf8";

            connection = new MySqlConnection(connectionString);

            try
            {
                connection.Open();
                MySqlCommand cmd = connection.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "delete from sample_table where name ='+textBox1.Text'";

                connection.Close();
            }
            catch (MySqlException ex)
            {
                //When handling errors, you can your application's response based 
                //on the error number.
                //The two most common error numbers when connecting are as follows:
                //0: Cannot connect to server.
                //1045: Invalid user name and/or password.
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot connect to server.  Contact administrator");
                        break;

                    case 1045:
                        MessageBox.Show("Invalid username/password, please try again");
                        break;
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            server = "127.0.0.1";
            database = "navic databases";
            uid = "root";
            password = "";
            string connectionString;
            connectionString = "SERVER=" + server + ";" + "DATABASE=" +
            database + ";" + "UID=" + uid + ";" + "PASSWORD=" + password + ";" + "CharSet = utf8";

            connection = new MySqlConnection(connectionString);

            try
            {

                connection.Open();
                MySqlCommand cmd = connection.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "update table set name '+textBox2.Text' where name is '+textBox1.Text' ";
                connection.Close();
            }
            catch (MySqlException ex)
            {
                //When handling errors, you can your application's response based 
                //on the error number.
                //The two most common error numbers when connecting are as follows:
                //0: Cannot connect to server.
                //1045: Invalid user name and/or password.
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot connect to server.  Contact administrator");
                        break;

                    case 1045:
                        MessageBox.Show("Invalid username/password, please try again");
                        break;
                }
            }
        }
        private void button4_Click(object sender, EventArgs e)
        {
            server = "127.0.0.1";
            database = "navic databases";
            uid = "root";
            password = "";
            string connectionString;
            connectionString = "SERVER=" + server + ";" + "DATABASE=" +
            database + ";" + "UID=" + uid + ";" + "PASSWORD=" + password + ";" + "CharSet = utf8";

            connection = new MySqlConnection(connectionString);

            try
            {
                connection.Open();

                MySqlCommand cmd = connection.CreateCommand();
                cmd.CommandText = "select*from sample_table";
                DataTable dt = new DataTable();
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                da.Fill(dt);
                connection.Close();
            }
            catch (MySqlException ex)
            {
                //When handling errors, you can your application's response based 
                //on the error number.
                //The two most common error numbers when connecting are as follows:
                //0: Cannot connect to server.
                //1045: Invalid user name and/or password.
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot connect to server.  Contact administrator");
                        break;

                    case 1045:
                        MessageBox.Show("Invalid username/password, please try again");
                        break;
                }
            }
        }
    }
    }


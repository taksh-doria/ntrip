﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data;

namespace demo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            MySqlConnection con = new MySqlConnection(@"http://localhost/phpmyadmin/tbl_structure.php?server=1&db=navic+databases&table=ntrip_source_table");
            InitializeComponent();
        }

       

        private void button1_Click(object sender, EventArgs e)
        {
            Connection.open();
            MySqlCommand cmd= Connection.createcommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText="insert into Sample_table values ('"+textBox1.Text"')";
            cmd.ExecuteQuery();
            Connection.close();
        }

        private void button2_Click(object sender, EventArgs e)
       {
            Connection.open();
            MySqlCommand cmd= Connection.createcommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText="delete from Sample_table where name ='"+textBox1.Text"'";
            cmd.ExecuteQuery();
            Connection.close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Connection.open();
            MySqlCommand cmd= Connection.createcommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText="update table set name+'"+textBox2.Text"' where name '"+textBox1.Text"'";
            cmd.ExecuteQuery();
            Connection.close();
        }
        private void button4_Click(object sender, EventArgs e)
        {
            Connection.open();
            MySqlCommand cmd = Connection.createcommand();
            cmd.CommandText="select*from Sample_table";
            DataTable dt = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);
           GridView1.datasource = dt;
           GridView1.databind();
        }
    }
}

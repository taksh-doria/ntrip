﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace display
{
    public partial class Form1 : Form
    {
        DataSet ds = new DataSet();
        MySqlConnection con = new MySqlConnection(@"Datasource=localhost;port=3306;Userid=root;Password=");
        MySqlDataAdapter daD = new MySqlDataAdapter();


        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            daD.InsertCommand = new MySqlCommand("Insert into sample_table VALUES (@Id,@Username,@Password,@Mobile_no)", con);
            /*daD.InsertCommand.Parameter.Add("@Username", SqlDbType.VarChar).value = txtUsername.Text;
            daD.InsertCommand.Parameter.Add("@Password", SqlDbType.VarChar).value = txtPassword.Text;
            daD.InsertCommand.Parameter.Add("@Mobile_no", SqlDbType.VarChar).value =txtMobile_no.Text;*/
            con.Open();
            daD.InsertCommand.ExecuteNonQuery();
            con.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            daD.SelectCommand = new MySqlCommand("Select*from Sample_table", con);
           //daD.Fill(con);
           // dg.DataSource = ds.Tables["Username"];


        }
    }
}

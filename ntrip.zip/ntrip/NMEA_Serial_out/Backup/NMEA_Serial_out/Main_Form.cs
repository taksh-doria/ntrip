﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.IO;
using System.IO.Ports;
using System.Net.Sockets;
using System.Net;
using System.Timers;
using System.Diagnostics;
using System.Threading;

namespace NMEA_Serial_out
{
    public partial class NMEA_OUT : Form
    {
         string   port_name,baudrate,databits ,parity, stopbits ,handshake,filepath;
         FileStream fsIn; 
         StreamReader sr;
         int loop_Count = 5;
         bool display_flag = true;
           
            
        public NMEA_OUT()
        {
            InitializeComponent();
        }

      

        private void button3_Click_1(object sender, EventArgs e)
        {
           
           
        }
         
        private void NMEA_OUT_Load(object sender, EventArgs e)
        {
            string[] ports = SerialPort.GetPortNames();

            foreach (string port in ports)
            {
                portname_cb.Items.Add(port);

            }

            if (File.Exists("Config.txt"))
            {

                FileStream fsIn2 = new FileStream("Config.txt", FileMode.Open, FileAccess.Read, FileShare.Read);
                StreamReader sr2 = new StreamReader(fsIn2);
                portname_cb.Text = sr2.ReadLine();
                baudrate_cb.Text = sr2.ReadLine();
                databits_cb.Text = sr2.ReadLine();
                stopbits_cb.Text = sr2.ReadLine();
                parity_cb.Text = sr2.ReadLine();
                handshake_cb.Text = sr2.ReadLine();
                sr2.Close();
                fsIn2.Close();
            }
            else
            {
                MessageBox.Show("Config.txt file missing.\nKindly reinstall IRNSS PTR software.");
                this.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (display_flag)
            {
                openFileDialog1.ShowDialog();

                filepath = openFileDialog1.FileName;
                textBox1.Text = filepath;



                try
                {


                    fsIn = new FileStream(filepath, FileMode.Open, FileAccess.Read, FileShare.Read);
                    sr = new StreamReader(fsIn);
                }
                catch (Exception e1)
                {
                    MessageBox.Show("Please Select the correct Foleder containing NMEA.txt file");
                }
            }
            

        }

        private void button2_Click(object sender, EventArgs e)
        {
            port_name = portname_cb.SelectedItem.ToString();
            baudrate = baudrate_cb.SelectedItem.ToString();
            databits = databits_cb.SelectedItem.ToString();
            stopbits = stopbits_cb.SelectedItem.ToString();
            parity = parity_cb.SelectedItem.ToString();
            handshake = handshake_cb.SelectedItem.ToString();

            if (File.Exists("Config.txt"))
            {
                FileStream fsIn2 = new FileStream("Config.txt", FileMode.Open, FileAccess.ReadWrite, FileShare.ReadWrite);
                StreamWriter sr2 = new StreamWriter(fsIn2);
                string[] tmpStr = new string[6];
                tmpStr[0] = port_name;
                sr2.WriteLine(tmpStr[0]);
                tmpStr[1] = baudrate;
                sr2.WriteLine(tmpStr[1]);
                tmpStr[2] = databits;
                sr2.WriteLine(tmpStr[2]);
                tmpStr[3] = stopbits;
                sr2.WriteLine(tmpStr[3]);
                tmpStr[4] = parity;
                sr2.WriteLine(tmpStr[4]);
                tmpStr[5] = handshake;
                sr2.WriteLine(tmpStr[5]);

                sr2.Close();
                fsIn2.Close();
            }

           
           
           
            if (!display_flag)
            {
                try
                {

                    COM_OUT.Close();
                    button2.Text = "START";
                    button2.ForeColor = Color.Green;
                    timer1.Enabled = false;
                    display_flag = true;
                    return;
                  
                }
                catch (Exception e1)
                {
                    MessageBox.Show("Please Select the correct Serial port settings and click on Start/Stop button");
                    timer1.Enabled = false;
              
                    return;
                }
                
            }
            else
            {
                try
                {
                    COM_OUT.PortName = port_name;
                    COM_OUT.BaudRate = int.Parse(baudrate);
                    COM_OUT.DataBits = int.Parse(databits);

                    if (parity == "None")
                        COM_OUT.Parity = Parity.None;
                    else if (parity == "Even")
                        COM_OUT.Parity = Parity.Even;
                    else if (parity == "Mark")
                        COM_OUT.Parity = Parity.Mark;
                    else if (parity == "Odd")
                        COM_OUT.Parity = Parity.Odd;
                    else if (parity == "Space")
                        COM_OUT.Parity = Parity.Space;

                    if (stopbits == "None")
                        COM_OUT.StopBits = StopBits.None;
                    else if (stopbits == "One")
                        COM_OUT.StopBits = StopBits.One;
                    else if (stopbits == "OnePointFive")
                        COM_OUT.StopBits = StopBits.OnePointFive;
                    else if (stopbits == "Two")
                        COM_OUT.StopBits = StopBits.Two;

                    if (handshake == "None")
                        COM_OUT.Handshake = Handshake.None;
                    else if (handshake == "RequestToSend")
                        COM_OUT.Handshake = Handshake.RequestToSend;
                    else if (handshake == "RequestToSendXOnXOff")
                        COM_OUT.Handshake = Handshake.RequestToSendXOnXOff;
                    else if (handshake == "XOnXOff")
                        COM_OUT.Handshake = Handshake.XOnXOff;

                    port_name = portname_cb.SelectedItem.ToString();
                    baudrate = baudrate_cb.SelectedItem.ToString();
                    databits = databits_cb.SelectedItem.ToString();
                    stopbits = stopbits_cb.SelectedItem.ToString();
                    parity = parity_cb.SelectedItem.ToString();
                    handshake = handshake_cb.SelectedItem.ToString();
                    COM_OUT.Open();
                    button2.Text = "STOP";
                    button2.ForeColor = Color.Red;
                    timer1.Enabled = true;
                    display_flag = false;
                   
                }
                catch (Exception e1)
                {
                    MessageBox.Show("Please Select the correct Serial port settings and click on Start/Stop button");
                  
                    timer1.Enabled = false;
                    
                    return;
                }
               
            }

         
             
          

            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {

                textBox2.Text = "";
                string str;

                for (int i = 0; i < loop_Count; i++)
                {
                    str = sr.ReadLine();
                    textBox2.Text += str + "\r\n";

                    COM_OUT.WriteLine(str + "\r\n");
                }
            }
            catch (Exception e1)
            {
               
                timer1.Enabled = false;
                button2.PerformClick();
           
                MessageBox.Show("Please Select the correct folder containing NMEA.txt file");
               
            }
           
 
        }
    }
}

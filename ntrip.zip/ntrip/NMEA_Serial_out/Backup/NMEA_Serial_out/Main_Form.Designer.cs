﻿namespace NMEA_Serial_out
{
    partial class NMEA_OUT
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.COM_OUT = new System.IO.Ports.SerialPort(this.components);
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.handshake_cb = new System.Windows.Forms.ComboBox();
            this.Handshake_1 = new System.Windows.Forms.Label();
            this.parity_cb = new System.Windows.Forms.ComboBox();
            this.stopbits_cb = new System.Windows.Forms.ComboBox();
            this.databits_cb = new System.Windows.Forms.ComboBox();
            this.baudrate_cb = new System.Windows.Forms.ComboBox();
            this.portname_cb = new System.Windows.Forms.ComboBox();
            this.Parity_1 = new System.Windows.Forms.Label();
            this.Stopbits = new System.Windows.Forms.Label();
            this.Databits = new System.Windows.Forms.Label();
            this.Baudrate = new System.Windows.Forms.Label();
            this.portname = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(356, 92);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(118, 27);
            this.button1.TabIndex = 0;
            this.button1.Text = "Browse";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.Teal;
            this.button2.Location = new System.Drawing.Point(202, 127);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(109, 29);
            this.button2.TabIndex = 1;
            this.button2.Text = "Start";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(94, 95);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(258, 20);
            this.textBox1.TabIndex = 2;
            // 
            // handshake_cb
            // 
            this.handshake_cb.FormattingEnabled = true;
            this.handshake_cb.Items.AddRange(new object[] {
            "None",
            "XOnXOff",
            "RequestToSend",
            "RequestToSendXOnXOff"});
            this.handshake_cb.Location = new System.Drawing.Point(307, 65);
            this.handshake_cb.Name = "handshake_cb";
            this.handshake_cb.Size = new System.Drawing.Size(79, 21);
            this.handshake_cb.TabIndex = 19;
            // 
            // Handshake_1
            // 
            this.Handshake_1.AutoSize = true;
            this.Handshake_1.Location = new System.Drawing.Point(241, 68);
            this.Handshake_1.Name = "Handshake_1";
            this.Handshake_1.Size = new System.Drawing.Size(62, 13);
            this.Handshake_1.TabIndex = 18;
            this.Handshake_1.Text = "Handshake";
            // 
            // parity_cb
            // 
            this.parity_cb.FormattingEnabled = true;
            this.parity_cb.Items.AddRange(new object[] {
            "None",
            "Odd",
            "Even",
            "Mark",
            "Space"});
            this.parity_cb.Location = new System.Drawing.Point(307, 39);
            this.parity_cb.Name = "parity_cb";
            this.parity_cb.Size = new System.Drawing.Size(79, 21);
            this.parity_cb.TabIndex = 15;
            // 
            // stopbits_cb
            // 
            this.stopbits_cb.FormattingEnabled = true;
            this.stopbits_cb.Items.AddRange(new object[] {
            "None",
            "One",
            "OnePointFive",
            "Two"});
            this.stopbits_cb.Location = new System.Drawing.Point(307, 12);
            this.stopbits_cb.Name = "stopbits_cb";
            this.stopbits_cb.Size = new System.Drawing.Size(79, 21);
            this.stopbits_cb.TabIndex = 16;
            // 
            // databits_cb
            // 
            this.databits_cb.FormattingEnabled = true;
            this.databits_cb.Items.AddRange(new object[] {
            "4",
            "5",
            "6",
            "7",
            "8",
            "9"});
            this.databits_cb.Location = new System.Drawing.Point(155, 66);
            this.databits_cb.Name = "databits_cb";
            this.databits_cb.Size = new System.Drawing.Size(82, 21);
            this.databits_cb.TabIndex = 17;
            // 
            // baudrate_cb
            // 
            this.baudrate_cb.FormattingEnabled = true;
            this.baudrate_cb.Items.AddRange(new object[] {
            "75",
            "110",
            "134",
            "150",
            "300",
            "600",
            "1200",
            "1800",
            "2400",
            "4800",
            "9600",
            "14400",
            "19200",
            "38400",
            "57600",
            "115200",
            "128000"});
            this.baudrate_cb.Location = new System.Drawing.Point(155, 39);
            this.baudrate_cb.Name = "baudrate_cb";
            this.baudrate_cb.Size = new System.Drawing.Size(82, 21);
            this.baudrate_cb.TabIndex = 13;
            // 
            // portname_cb
            // 
            this.portname_cb.FormattingEnabled = true;
            this.portname_cb.Location = new System.Drawing.Point(155, 12);
            this.portname_cb.Name = "portname_cb";
            this.portname_cb.Size = new System.Drawing.Size(82, 21);
            this.portname_cb.TabIndex = 14;
            // 
            // Parity_1
            // 
            this.Parity_1.AutoSize = true;
            this.Parity_1.Location = new System.Drawing.Point(256, 42);
            this.Parity_1.Name = "Parity_1";
            this.Parity_1.Size = new System.Drawing.Size(33, 13);
            this.Parity_1.TabIndex = 9;
            this.Parity_1.Text = "Parity";
            // 
            // Stopbits
            // 
            this.Stopbits.AutoSize = true;
            this.Stopbits.Location = new System.Drawing.Point(250, 15);
            this.Stopbits.Name = "Stopbits";
            this.Stopbits.Size = new System.Drawing.Size(44, 13);
            this.Stopbits.TabIndex = 8;
            this.Stopbits.Text = "Stop Bit";
            // 
            // Databits
            // 
            this.Databits.AutoSize = true;
            this.Databits.Location = new System.Drawing.Point(95, 69);
            this.Databits.Name = "Databits";
            this.Databits.Size = new System.Drawing.Size(50, 13);
            this.Databits.TabIndex = 10;
            this.Databits.Text = "Data Bits";
            // 
            // Baudrate
            // 
            this.Baudrate.AutoSize = true;
            this.Baudrate.Location = new System.Drawing.Point(95, 42);
            this.Baudrate.Name = "Baudrate";
            this.Baudrate.Size = new System.Drawing.Size(50, 13);
            this.Baudrate.TabIndex = 12;
            this.Baudrate.Text = "Baudrate";
            // 
            // portname
            // 
            this.portname.AutoSize = true;
            this.portname.Location = new System.Drawing.Point(92, 15);
            this.portname.Name = "portname";
            this.portname.Size = new System.Drawing.Size(57, 13);
            this.portname.TabIndex = 11;
            this.portname.Text = "Port Name";
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(12, 162);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(462, 160);
            this.textBox2.TabIndex = 21;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(18, 97);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 16);
            this.label1.TabIndex = 22;
            this.label1.Text = "File Path";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = global::NMEA_Serial_out.Properties.Resources.SAC_LOGO;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(393, 21);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(84, 58);
            this.pictureBox2.TabIndex = 24;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::NMEA_Serial_out.Properties.Resources.ISRO_LOGO;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(3, 8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(84, 78);
            this.pictureBox1.TabIndex = 23;
            this.pictureBox1.TabStop = false;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 326);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(486, 22);
            this.statusStrip1.TabIndex = 25;
            this.statusStrip1.Text = "Developed by SNTD/DCTG/SNAA";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(349, 17);
            this.toolStripStatusLabel1.Text = "                                        Developed by SNTD/DCTG/SNAA              " +
                " ";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // NMEA_OUT
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(486, 348);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.handshake_cb);
            this.Controls.Add(this.Handshake_1);
            this.Controls.Add(this.parity_cb);
            this.Controls.Add(this.stopbits_cb);
            this.Controls.Add(this.databits_cb);
            this.Controls.Add(this.baudrate_cb);
            this.Controls.Add(this.portname_cb);
            this.Controls.Add(this.Parity_1);
            this.Controls.Add(this.Stopbits);
            this.Controls.Add(this.Databits);
            this.Controls.Add(this.Baudrate);
            this.Controls.Add(this.portname);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(502, 386);
            this.MinimumSize = new System.Drawing.Size(502, 386);
            this.Name = "NMEA_OUT";
            this.Text = "NMEA OUT";
            this.Load += new System.EventHandler(this.NMEA_OUT_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.IO.Ports.SerialPort COM_OUT;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ComboBox handshake_cb;
        private System.Windows.Forms.Label Handshake_1;
        private System.Windows.Forms.ComboBox parity_cb;
        private System.Windows.Forms.ComboBox stopbits_cb;
        private System.Windows.Forms.ComboBox databits_cb;
        private System.Windows.Forms.ComboBox baudrate_cb;
        private System.Windows.Forms.ComboBox portname_cb;
        private System.Windows.Forms.Label Parity_1;
        private System.Windows.Forms.Label Stopbits;
        private System.Windows.Forms.Label Databits;
        private System.Windows.Forms.Label Baudrate;
        private System.Windows.Forms.Label portname;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
    }
}


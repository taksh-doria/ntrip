﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data;

namespace Insert_data
{
    public partial class Form1 : Form
    {
        MySqlConnection connnection = new MySqlConnection("datasource=localhost;port:3306;username=root;password=");

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
        string insrtquery= MySqlCommand Cmd=new MySqlCommand("insertquery,connection");
        //INSERT INTO Sample_table ("Id","Username","Password","Mobile_no") VALUES ('"+textboxId.Text"'+'"textboxUsername.Text"'+'"textboxPassword.Text"'+'"textboxMobile_no.Text"');
        }
          connnection.Open();
            {
                try
                {
                    if  (Cmd.executenonquery()==1)
                    {
                      MessageBox.Show ("data inserted");
                    }
                    else
                {

                        MessageBox.Show("data is not inserted");
                } 
                    catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                connnection.close();

            }
        }
}
}

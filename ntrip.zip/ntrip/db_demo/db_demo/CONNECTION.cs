﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.data.mysqlclient;

namespace CONNECTION
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                MySqlConnection connection = new MySqlConnection("datasource=localhost;port=3306;username:root;password=");
                MySqlDataAdapter adapter=new MySqlDataAdapter("select*from sample_table connection");
                DataSet ds=new DataSet();
                adapter.fill(ds,"users");
                dataGridView1.DataSource=ds.Tables["users"];
                connection.close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}

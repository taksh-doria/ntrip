﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.data.mysqlclient;


namespace Delete_data
{
    public partial class Form1 : Form
    {
        MySqlconnecation connection = new MySqlconnecation("datasource=localhost;port=3306;username=root;password=");

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string deletequery = "DELETE FROM sample_table WHERE id=" + sample_table_id.text;
                connection.open();
                MySqlCommand command = new MySqlCommand(deletequery, connection);
                if (command.Executenonquery() == 1)
                {
                    MessageBox.Show("user delete");
                }
                else
                {
                    MessageBox.Show("usern't delete");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            connection.close();
        }
        }
    }


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Ntrip_Client
{
    public partial class Form1 : Form
    {
        MySqlConnection connection;

        string server;
        string database;
        string uid;
        string password;
      
        public Form1()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            {
                server = "127.0.0.1";
                database = "navic databases";
                uid = "root";
                password = "";
                string connectionString;
                connectionString = "SERVER=" + server + ";" + "DATABASE=" +
                database + ";" + "UID=" + uid + ";" + "PASSWORD=" + password + ";" + "CharSet = utf8";

                connection = new MySqlConnection(connectionString);

                try
                {
                    connection.Open();
                    MySqlCommand SqlCommand = new MySqlCommand("SELECT * FROM user_authentication WHERE 1", connection);

                    MessageBox.Show(SqlCommand.ToString());

                    using ( MySqlDataReader reader = SqlCommand.ExecuteReader())
                    {
                        Console.WriteLine("FirstColumn\tSecond Column\t\tThird Column\t\tForth Column\t");
                        while (reader.Read())
                        {
                            Console.WriteLine(String.Format("{0} \t | {1} \t | {2} \t | {3} \t | {4}",
                                reader[0], reader[1], reader[2], reader[3], reader[4]));
                        }
                    }


                }
                catch (MySqlException ex)
                {
                    //When handling errors, you can your application's response based 
                    //on the error number.
                    //The two most common error numbers when connecting are as follows:
                    //0: Cannot connect to server.
                    //1045: Invalid user name and/or password.
                    switch (ex.Number)
                    {
                        case 0:
                            MessageBox.Show("Cannot connect to server.  Contact administrator");
                            break;

                        case 1045:
                            MessageBox.Show("Invalid username/password, please try again");
                            break;
                    }

                }
            }
          /*  try
            {
                if (textBox1.Text!=""&& textBox2.Text!="")
                    
                {
                    con= new MySqlConnection(strProvider);
                    con.Open();
                    string query = "select Id, Username, Birthdate,Password from user_authentication WHERE username ='" + textBox1.Text + "' AND password ='" + textBox2.Text + "'";
                   MySqlCommand SqlCommand = new MySqlCommand(query,con);
                   MySqlDataReader row;
                    row = SqlCommand.ExecuteReader();
                    if (row.HasRows)
                    {
                        while (row.Read())
                        {
                            Id = row["Id"].ToString();
                            Username = row["Username"].ToString();
                            Birthdate = row["Birthdate"].ToString();
                            Password = row["Password"].ToString();

                        } MessageBox.Show("Data found your name is " + Username + " " + " and your Id  is " + Id);
                    }
                    else
                    {
                        MessageBox.Show("Data not found", "Information");
                    }
                }
                else
                {
                    MessageBox.Show("Username or Password is empty", "Information");
                }
            }
            catch(Exception e1)
            {
                MessageBox.Show("Connection Error", "Information");
            }*/
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

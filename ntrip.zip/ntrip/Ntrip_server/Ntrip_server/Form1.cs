﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data;
using System.IO.Ports;
using System.IO;

namespace Ntrip_server 
{
    public partial class Form1 : Form
    {
        MySqlConnection connection;
        string server;
        string database;
        string uid;
        string password;
        public static string internalLog = "";
        
        int Stop_flag = 0;
        string str;
        StreamWriter w2;
        public Form1()
        {
            InitializeComponent();
            server = "127.0.0.1";
            database = "test";
            uid = "root";
            password = "";
            string connectionString;
            connectionString = "SERVER=" + server + ";" + "DATABASE=" +
            database + ";" + "UID=" + uid + ";" + "PASSWORD=" + password + ";" + "CharSet = utf8";
            connection = new MySqlConnection(connectionString);
            connection.Open();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            //   CheckForIllegalCrossThreadCalls = false;

            string[] ports = SerialPort.GetPortNames();

            foreach (string port in ports)
            {
                comboBox1.Items.Add(port);
            }

            if (File.Exists("Config.txt"))
            {

                FileStream fsIn2 = new FileStream("Config.txt", FileMode.Open, FileAccess.Read, FileShare.Read);
                StreamReader sr2 = new StreamReader(fsIn2);
                comboBox1.Text = sr2.ReadLine();
               
            }
        }

        private void read_data(object c)
        {
            string current_system_time_log = System.DateTime.Now.Year + "-" + System.DateTime.Now.Month + "-" + System.DateTime.Now.Day + "_" + System.DateTime.Now.Hour + "-" + System.DateTime.Now.Minute + "-" + System.DateTime.Now.Second;
            internalLog = "IRNSS" + current_system_time_log;
            Directory.CreateDirectory(internalLog);
            serialPort1.BaudRate = 115200;

            int log_count = 0;
            double line_count = 0;
            timer1.Enabled = true;
            while (true)
            {
                Stop_flag = 0;
                try
                {
                    if (serialPort1.BytesToRead > 0)
                    {
                        str = serialPort1.ReadLine();
                        string[] byThis = str.Split(new string[] { ":", "\r" }, StringSplitOptions.RemoveEmptyEntries);
                        string[] byThis2 = str.Split(new string[] { ":", "\r" }, StringSplitOptions.RemoveEmptyEntries);
                        line_count++;
                        if (byThis[0] == "ID")
                        {
                            log_count++;
                            line_count--;
                        }
                        if (str == "END\r")
                        {
                            timer1.Enabled = false;
                            serialPort1.BaudRate = 9600;
                            current_system_time_log = System.DateTime.Now.Year + "-" + System.DateTime.Now.Month + "-" + System.DateTime.Now.Day + "_" + System.DateTime.Now.Hour + "-" + System.DateTime.Now.Minute + "-" + System.DateTime.Now.Second;
                            double time = (line_count * 5) / 60;
                            int time_min = (int)(time * 100);
                            time = time_min / 100.0;
                            textBox2.Text = time.ToString() + " minutes Data Read Successfully \r\n";
                            break;
                        }
                    }
                }
                catch (Exception e1)
                {
                }
            }
            serialPort1.BaudRate = 9600;
            serialPort1.Close();
            MessageBox.Show("File read successfully");
            button1.PerformClick();
            // Application.Exit();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
           try
           {
               serialPort1.Open();
               {
                   while (true)
                   {
                       if (serialPort1.BytesToRead > 0)
                       {
                           byte b = (byte)serialPort1.ReadByte();
                           str = serialPort1.ReadLine();
                           Console.WriteLine(str);
                       }
                   }    
               }
               int insert_cnt = 0;
               DateTime datetime = DateTime.Now;
               MySqlCommand insertCommand = new MySqlCommand("INSERT INTO ntrip_server (Date_Time, Server_Id, RTCM_Data) VALUES ('" + datetime + "','" + "1499" + "','" + "hello.hi" + "')", connection);
               insertCommand.ExecuteNonQuery();
               insert_cnt++;
               if ((insert_cnt % 10) == 0)
               {
                   Console.WriteLine("inserted " + insert_cnt.ToString() + "Record");
               }
           }
            catch (MySqlException ex)
            {
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot connect to server.  Contact administrator");
                        break;

                    case 1045:
                        MessageBox.Show("Invalid username/password, please try again");
                        break;
                }
            }
       }
        private void button2_Click(object sender, EventArgs e)
        {
            timer2.Enabled = true;
        }
        private void timer2_Tick(object sender, EventArgs e)
        {
            try
            {
                MySqlCommand SqlCommand = new MySqlCommand("SELECT * FROM ntrip_server ORDER BY Date_Time ASC,Server_Id ASC,RTCM_Data ASC", connection);
                using (MySqlDataReader reader = SqlCommand.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        this.textBox1.Text = reader[0].ToString();
                        this.textBox3.Text = reader[2].ToString();
                    }
                }
            }
            catch (MySqlException ex)
            {
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot connect to server.Contact administrator");
                        break;

                    case 1045:
                        MessageBox.Show(" please try again");
                        break;
                }
            }
        }
    }
}

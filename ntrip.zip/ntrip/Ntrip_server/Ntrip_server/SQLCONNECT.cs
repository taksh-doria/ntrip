﻿using System;

public class SQLCONNECT
{
    public SQLCONNECT con();
   public void connection()
	{
	}
}
